from colour import Color


distinguishable_colors = (
    (240, 163, 255),  # F0A3FF Amethyst
    (0, 117, 220),  # 0075DC Blue
    (153, 63, 0),  # 993F00	Caramel
    (76, 0, 92),  # 4C005C	Damson
    (25, 25, 25),  # 191919	Ebony
    (0, 92, 49),  # 005C31	Forest
    (43, 206, 72),  # 2BCE48 Green
    (255, 204, 153),  # FFCC99 Honeydew
    (128, 128, 128),  # 808080 Iron
    (148, 255, 181),  # 94FFB5 Jade
    (143, 124, 0),  # 8F7C00 Khaki
    (157, 204, 0),  # 9DCC00 Lime
    (194, 0, 136),  # C20088 Mallow
    (0, 51, 128),  # 003380	Navy
    (255, 164, 5),  # FFA405 Orpiment
    (255, 168, 187),  # FFA8BB Pink
    (66, 102, 0),  # 426600	Quagmire
    (255, 0, 16),  # FF0010	Red
    (94, 241, 242),  # 5EF1F2 Sky
    (0, 153, 143),  # 00998F Turquoise
    (224, 255, 102),  # E0FF66	Uranium
    (116, 10, 255),  # 740AFF Violet
    (153, 0, 0),  # 990000	Wine
    (255, 255, 128),  # FFFF80 Xanthin
    (255, 255, 0),  # FFFF00 Yellow
    (255, 80, 5),  # FF5005 Zinnia
)


def select_color():
    """Return a nice color

    Function loops through a list of visible, distinguishable colors

    Returns
    -------
    Color
        A nice, visible color
    """
    color = Color(
        rgb=(c / 255 for c in distinguishable_colors[select_color.current_color])
    )
    select_color.current_color += 1
    if select_color.current_color == len(distinguishable_colors):
        select_color.current_color = 0
    return color


select_color.current_color = 0


def to_color(value, choose=False):
    """Convert input to color

    Parameters
    ----------
    value : Any
        Input that needs to be converted into a color
    choose : bool
        Whether a color should be picked if input was None

    Returns
    -------
    Color
        The converted or selected color
    """
    if choose:
        value = value or select_color()
    if isinstance(value, str):
        if value.lower()[0:3] == "hsl":
            hsl = value[4:-1].replace("%", "").split(",")
            hsl = [float(f) / 100 for f in hsl]
            hsl[0] = hsl[0] * 100
            return Color(hsl=hsl)
        elif value.lower()[0:3] == "rgb":
            rgb = value[4:-1].split(",")
            rgb = [float(f) / 255 for f in rgb]
            return Color(rgb=rgb)
    return Color(value)
