import abc


class LazyAttribute:
    """Placeholder attribute for lazy attributes"""
    def __repr__(self):
        return f"<< {self.__class__.__name__} >>"


class LazyLoadingClass(abc.ABC):
    """Partially instantiated objects, only send a request for additional data when it is needed"""

    @property
    def lazy(self):
        """List of the names of the lazy attributes of the instance

        Returns
        -------
        list of str
            Names of lazy attributes
        """
        return [key for key, value in self.__dict__.items() if isinstance(value, LazyAttribute)]

    @abc.abstractmethod
    def _full_instance(self):
        """Send a get request to get the fully defined instance from the appliance

        The full instance can be used to set the attributes that are lazy.
        """
        pass

    def _load(self):
        """Retrieve a full instance from the appliance and fill in the lazy attributes"""
        full = self._full_instance()
        for attr in self.lazy:
            object.__setattr__(self, attr, full.__getattribute__(attr))

    def __getattribute__(self, item, n=0):
        """Overwrite to check if attribute is lazy, and retrieve data from the appliance if it is """
        value = object.__getattribute__(self, item)
        if isinstance(value, LazyAttribute):
            if n > 4:  # safety feature to avoid infinite requests to the appliance if attributes are not set correctly
                raise RecursionError
            self._load()
            return self.__getattribute__(item, n=n+1)
        return value
