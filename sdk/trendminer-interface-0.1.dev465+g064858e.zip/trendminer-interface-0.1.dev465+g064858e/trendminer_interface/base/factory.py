import abc
import posixpath

from requests.exceptions import HTTPError

from trendminer_interface import _input as ip
from trendminer_interface.authentication import Authenticated
from trendminer_interface.exceptions import ResourceNotFound, FromJsonError
from trendminer_interface.constants import MAX_GET_SIZE
from .lazy_loading import LazyAttribute


class TrendMinerFactory(Authenticated, abc.ABC):
    """Superclass for all factories instantiating new methods"""
    tm_class = None

    def from_identifier(self, ref):
        """Load an instance directly from its unique identifier

        Parameters
        ----------
        ref : str
            Unique identifier to the object on the appliance

        Returns
        -------
        Any
            The appliance object with the given unique identifier
        """
        try:
            link = posixpath.join(self.tm_class.endpoint, ref)
        except TypeError:
            raise ResourceNotFound(ref)
        response = self.client.session.get(link)
        return self.from_json(response.json())

    def from_json(self, data):
        """Create instance from the json data returned from the appliance

        The same object can be represented by a multitude of json structures, depending on what request was sent to the
        appliance. The default way to attempt to assemble an instance is to try a number of methods in a given order
        (from high to low information content). The methods to try are given by the `_from_json_methods` property.

        In case only a single representation of a class exists on the appliance, the entire `from_json` method can be
        overwritten.

        Parameters
        ----------
        data : dict
            json structure returned from appliance

        Returns
        -------
        Any
            The assembled instance
        """
        for method in self._from_json_methods:
            try:
                return method(data)
            except (TypeError, KeyError, AttributeError, FromJsonError):
                pass
        raise FromJsonError(data)

    @property
    def _from_json_methods(self):
        """Methods to try to assemble an instance from a json structure"""
        return ()

    @property
    def _get_methods(self):
        """Methods to try to retrieve an instance from the appliance

        get methods always have the following syntax: `from_*`
        """
        return ()

    @property
    def _search_methods(self):
        """Methods by which to search instances on the appliance

        search methods always have the following syntax: `by_*`
        """
        return ()

    def get(self, ref):
        """Get instance from any possible reference type

        Tries all methods in `_get_methods` in order to retrieve an instance from the appliance.

        The given input is simply returned if:
        - It is already an instance of the correct type
        - It is None
        - It is a LazyAttribute

        Parameters
        ----------
        ref : Any
            Reference by which a unique instance can be retrieved from the appliance

        Returns
        -------
        Any
            The instance pointed to by the given reference
        """

        if ref is None:
            return None

        if isinstance(ref, LazyAttribute):
            return ref

        # Ref is already of correct instance, return
        if isinstance(ref, self.tm_class):
            return ref

        # Try converting from JSON format
        try:
            return self.from_json(ref)
        except (TypeError, KeyError, AttributeError, FromJsonError):
            pass

        # Try all other implemented methods to return data
        for method in self._get_methods:
            try:
                return method(ref)
            except (ResourceNotFound, HTTPError, AttributeError):
                pass  # TODO: should not pass on 401 client error

        raise ResourceNotFound(f"No match for {ref} found")

    def search(self, ref):
        """Search instances by any possible reference type

        Can execute multiple search methods as given by the `_search_methods` property, and return the collection of all
        results (without duplicates when multiple methods return overlapping instances).

        Parameters
        ----------
        ref : str
            String reference by which to call the search methods

        Returns
        -------
        list
            List of instances meeting the search criteria
        """
        results = [result for method in self._search_methods for result in method(ref)]
        return ip.unique_by_attribute(results, attribute="identifier")

    def list(self, refs):
        """Retrieves instances from list of references

        Uses the `get` method on every item in the given list.

        Parameters
        ----------
        refs : list
            list of references representing unique instances on the appliance. A single input is converted into a list
            of length 1.

        Returns
        -------
        list
            List of instances retrieved from given references
        """
        if isinstance(refs, LazyAttribute):
            return refs
        if isinstance(refs, (str, self.tm_class, tuple)):
            refs = [refs]
        refs = refs or []
        return [self.get(ref) for ref in refs]

    def all(self):
        """Retrieve all instances from the appliance

        Returns
        -------
        list
            List of all instances retrieved from the appliance
        """
        params = {"size": MAX_GET_SIZE}
        content = self.client.session.paginated(keys=["content"]).get(self.tm_class.endpoint, params=params)
        return [self.from_json(data) for data in content]

    def __ring_key__(self):
        """key for cacheing with the `ring` package

        Factories of the same class and with the same client should share a cache.

        Returns
        -------
        str
            key under which to cache factory methods in ring
        """
        return f"{hash(self.client)}:{self.__class__.__name__}"


class QuerySearchFactory(TrendMinerFactory, abc.ABC):
    """Factory for objects which can search using sql-style queries"""

    def _query_params(self, params):
        """Execute an sql-style query on the TrendMiner appliance

        Parameters
        ----------
        params : dict
            Request parameters. Needs to contain the sql query under the "query" key.

        Returns
        -------
        list
            List of instances matching the given query.
        """
        params.update({"size": MAX_GET_SIZE})
        content = self.client.session.paginated(keys=["content"]).get(self.tm_class.endpoint + "search", params=params)
        return [self.from_json(data) for data in content]

    def _query_search(self, ref, search_key):
        """Sends sql query where we search for a single given key to match a value

        Parameters
        ----------
        ref : str
            The value to match
        search_key : str
            The key which needs to match this value

        Returns
        -------
        list
            List of instances where the given key matches the given value
        """
        params = {"query": f"{search_key}=='{ref}'"}
        return self._query_params(params)

    def _query_in(self, refs, search_key):
        """Sends sql query where we search for a single given key to be any of a number of given values

        Parameters
        ----------
        refs : list of str
            The list of values the key should match one of
        search_key : str
            The key with which to match the value

        Returns
        -------
        list
            List of instances where the given key matches one of the given values
        """
        queries = ",".join([f"'{ref}'" for ref in refs])
        params = {"query": f"{search_key}=in=({queries})"}
        return self._query_params(params)
