import re

version_pattern = re.compile("([*\\d]{4}).R([*\\d]*).([*\\d]*)(-([*\\d]*))?")
version_matches = [1, 2, 3, 5]


class Version:
    """TrendMiner version object. Can be constructed from string and can be compared directly to another string
    can take comparisons with a wildcard *: 2021.R3.1-12 == 2021.R3.1-*
    """

    def __init__(self, year, major, minor, hotfix='*', nightly=False):
        self.year = year
        self.major = major
        self.minor = minor
        self.hotfix = hotfix
        self.nightly = nightly

    @classmethod
    def from_string(cls, version_string):
        """Create version instance from string"""
        if version_string.upper() == "NIGHTLY":
            return cls(year="*", major="*", minor="*", hotfix="*", nightly=True)
        match = version_pattern.fullmatch(version_string)
        values = []
        for i in version_matches:
            value = match[i]
            try:
                values.append(int(value))
            except (ValueError, TypeError):
                values.append("*")

        return cls(*values)

    @classmethod
    def get(cls, version):
        """Create version instance from string if needed. Guarantees output is a version instance."""
        if isinstance(version, cls):
            return version
        return cls.from_string(version)

    @property
    def tuple(self):
        return self.year, self.major, self.minor, self.hotfix

    def __repr__(self):
        return f"<< Version | {str(self)} >>"

    def __str__(self):
        if self.nightly:
            return "NIGHTLY"
        return f"{self.year}.R{self.major}.{self.minor}-{self.hotfix:02d}"

    def __eq__(self, other):
        if self.nightly:
            return False
        other = self.get(other)
        for i, j in zip(self.tuple, other.tuple):
            if not ('*' in [i, j] or i == j):
                return False
        return True

    def __lt__(self, other):
        if self.nightly:
            return False
        other = self.get(other)
        for i, j in zip(self.tuple, other.tuple):
            if '*' in [i, j] or i < j:
                return True
        return False

    def __gt__(self, other):
        if self.nightly:
            return True
        other = self.get(other)
        for i, j in zip(self.tuple, other.tuple):
            if '*' in [i, j] or i > j:
                return True
        return False

    def __le__(self, other):
        return (self == other) or (self < other)

    def __ge__(self, other):
        return (self == other) or (self > other)
