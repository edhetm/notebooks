
from trendminer_interface import _input as ip
from trendminer_interface.base import Savable, TrendMinerFactory, ByFactory
from trendminer_interface.user import UserFactory


class AccessRule(Savable):
    user = ByFactory(UserFactory)

    def __init__(self, client, identifier, parent, user, permissions, endpoint):
        super().__init__(client=client, identifier=identifier)
        self.parent = parent
        self.user = user
        self.permissions = permissions
        self.endpoint = endpoint

    def __json__(self):
        return {
            "identifier": self.identifier,
            "permissions": self.permissions,
            "subjectType": self.user.subject_type,
            "subjectId": self.user.identifier,
        }

    def blueprint(self):
        return {
            "user": self.user.name,
            "permissions": self.permissions
        }

    def __repr__(self):
        return f"<< AccessRule | {self.user.name}: {','.join(self.permissions)} >>"


class AccessRuleFactory(TrendMinerFactory):
    tm_class = AccessRule

    def __init__(self, parent, endpoint, option_dict, derived_option_dict=None):
        super().__init__(client=parent.client)
        self._parent = parent
        self._option_dict = option_dict
        self._derived_option_dict = derived_option_dict or {}
        self._endpoint = endpoint or ""  # suffix to the url; e.g. /inherited for inherited permissions

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            parent=self._parent,
            user=data.get("userDetailsResource", data["subjectType"]),
            permissions=data["permissions"],
            endpoint=self._endpoint,
        )

    def all(self):
        response = self.client.session.get(self._endpoint)
        return [self.from_json(data) for data in response.json()]

    def _validate_permissions(self, values):
        permissions = []
        values = ip.any_list(values)
        for value in values:
            value = ip.case_correct(value, self._option_dict.keys())
            value = self._option_dict[value]
            permissions.append(value)
            for derived_permission in self._derived_option_dict.get(value, []):
                permissions.append(derived_permission)
        return list(set(permissions))

    def add(self, user, permissions):
        rule = self.tm_class(
            client=self.client,
            identifier=None,
            parent=self._parent,
            user=user,
            permissions=self._validate_permissions(permissions),
            endpoint=self._endpoint,
        )
        rule.post()

    def remove(self, users):
        """Remove rules involving specific users

        Parameters
        ----------
        users : list
            Users for which all access rules need to be removed
        """
        users = self.client.user.list(users)
        identifiers = [user.identifier for user in users]
        for rule in self.all():
            if rule.user.identifier in identifiers:
                rule.delete()

    def clear(self):
        for rule in self.all():
            rule.delete()

    @property
    def _get_methods(self):
        return self.from_identifier,