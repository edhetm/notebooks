from trendminer_interface.base import TrendMinerFactory
from trendminer_interface.tag import Tag
from trendminer_interface.asset.node import Node


class ComponentFactory(TrendMinerFactory):
    tm_class = (Tag, Node)

    def all(self):
        raise NotImplementedError

    def from_identifier(self, ref):
        raise NotImplementedError

    def from_tag(self, ref):
        return self.client.tag.get(ref)

    def from_node(self, ref):
        return self.client.asset.get(ref)

    @property
    def _get_methods(self):
        return self.from_tag, self.from_node

    def from_json(self, data):
        component_type = data["type"]

        if component_type in ["ASSET", "ATTRIBUTE"]:
            return self.client.asset.from_json(data)

        if component_type == "TAG":
            return self.client.tag.from_json(data)

        raise TypeError(
            f'No handling for component type {data["type"]}'
        )