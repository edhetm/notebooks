import abc

from trendminer_interface.base import AsColor


class ColoredObject(abc.ABC):
    """An object that can have a color

    Parameters
    ----------
    color: Color or str, optional
        Chart display color. If no color is chosen, a random color is selected from a list of distinghuisable
        colors.
    """

    color = AsColor(choose=True)

    def __init__(self, color=None):
        self.color = color

    @property
    def api_color_ch(self):
        """ContextHub API color; does not contain a #"""
        return self.color.hex_l[1:].upper()

    @property
    def api_color(self):
        return self.color.hex_l.upper()
