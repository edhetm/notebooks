import abc
from .color import ColoredObject


class Scalable(ColoredObject, abc.ABC):
    """An object that can have a scale on a chart

    Parameters
    ----------
    scale: list, optional
        [min, max] scale on the chart
    """
    def __init__(self, color, scale):
        super().__init__(color=color)
        self.scale = scale

    @property
    def scale(self):
        return self._scale

    @scale.setter
    def scale(self, scale):
        if isinstance(scale, dict):
            if scale["scaleType"].upper() == "AUTO":
                scale = None
            else:
                scale = [scale["min"], scale["max"]]
        self._scale = scale

    def __json__(self):
        if self.scale is None:
            payload_scale = {"scaleType": "AUTO"}
        else:
            payload_scale = {
                "min": self.scale[0],
                "max": self.scale[1],
                "scaleType": "MANUAL",
            }
        return {
            "options": {
                "scale": payload_scale,
                "color": self.api_color,
            }
        }