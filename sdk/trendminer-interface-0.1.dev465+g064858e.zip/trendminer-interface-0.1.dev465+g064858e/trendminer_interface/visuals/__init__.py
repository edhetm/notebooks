from .color import ColoredObject
from .scalable import Scalable
from .shiftable import Shiftable