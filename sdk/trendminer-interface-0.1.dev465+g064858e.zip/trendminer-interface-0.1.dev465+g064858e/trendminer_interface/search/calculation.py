from trendminer_interface.constants import SEARCH_CALCULATION_OPTIONS
from trendminer_interface.base import TrendMinerFactory, HasOptions
from .tag import ReferencingTag


class SearchCalculation(ReferencingTag):
    operation = HasOptions(SEARCH_CALCULATION_OPTIONS)

    def __init__(
            self,
            client,
            key,
            tag,
            operation,
            units,
    ):
        super().__init__(client=client, tag=tag)

        self.operation = operation
        self.key = key
        self.units = units

    def __json__(self):
        return {
            **super().__json__(),
            "name": self.key,
            "type": self.operation,
            "unit": self.units,
        }

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self.tag.name} | {self.operation} >>"


class SearchCalculationFactory(TrendMinerFactory):
    tm_class = SearchCalculation

    def __call__(self, tag, operation, key=None, units=""):
        return self.tm_class(
            client=self.client,
            tag=tag,
            operation=operation,
            key=key,
            units=units,
        )

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            tag=data["reference"],
            operation=data["type"],
            key=data["name"],
            units=data["unit"],
        )

    def from_dict(self, refs):
        calculations = []
        for key, value in refs.items():
            tag = value[0]
            operation = value[1]
            try:
                units = value[2]
            except IndexError:
                units = ""
            calculations.append(
                self.tm_class(
                    client=self.client,
                    tag=tag,
                    operation=operation,
                    key=key,
                    units=units,
                )
            )
        return calculations

    def list(self, refs):
        try:
            return self.from_dict(refs)
        except AttributeError:
            return super().list(refs)

    @property
    def _get_methods(self):
        return ()