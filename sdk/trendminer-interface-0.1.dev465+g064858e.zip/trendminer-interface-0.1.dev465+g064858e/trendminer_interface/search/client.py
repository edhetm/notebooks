import abc

from trendminer_interface.exceptions import ResourceNotFound
from trendminer_interface.base import TrendMinerFactory
from trendminer_interface.exceptions import FromJsonError

from .value import ValueBasedSearchFactory


class SearchClient(abc.ABC):
    @property
    def search(self):
        return SearchFactory(client=self)


search_factories = [ValueBasedSearchFactory]


class SearchFactory(TrendMinerFactory):
    @property
    def value(self):
        return ValueBasedSearchFactory(client=self.client)

    def get(self, ref):
        for factory in search_factories:
            try:
                return factory(client=self.client).get(ref)
            except ResourceNotFound:
                pass
            raise ResourceNotFound(ref)

    def from_json(self, data):
        for factory in search_factories:
            try:
                return factory(client=self.client).from_json(data)
            except (TypeError, KeyError, AttributeError, FromJsonError):
                pass
            raise FromJsonError
