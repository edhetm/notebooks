import abc
import time

from trendminer_interface.work import WorkOrganizerObject, WorkOrganizerFactory
from trendminer_interface.constants import SEARCH_REFRESH_SLEEP, MAX_GET_SIZE
from trendminer_interface.times import IntervalFactory
from trendminer_interface.base import ByFactory

from .calculation import SearchCalculationFactory


class Search(WorkOrganizerObject, abc.ABC):
    search_type = None
    refresh_sleep = SEARCH_REFRESH_SLEEP

    interval = ByFactory(IntervalFactory, "__call__")
    calculations = ByFactory(SearchCalculationFactory, "list")

    def __init__(
            self,
            client,
            identifier,
            identifier_monitor,
            name,
            description,
            folder,
            owner,
            last_modified,
            calculations,
    ):
        super().__init__(client=client,
                         identifier=identifier,
                         name=name,
                         description=description,
                         folder=folder,
                         owner=owner,
                         last_modified=last_modified
                         )

        self.search_request_identifier = None
        self.calculations = calculations
        self.identifier_monitor = identifier_monitor

    @abc.abstractmethod
    def _full_instance(self):
        return super()._full_instance()

    @property
    @abc.abstractmethod
    def tags(self):
        pass

    def _post_updates(self, response):
        super()._post_updates(response)
        self.identifier_monitor = response.json()["data"]["id"]

    def _json_definition(self):
        return {
            "calculations": self.calculations,
            "type": self.content_type,
        }

    def execute(self, interval='6M', excluded_intervals=None):
        interval = self.client.time.interval(interval)
        excluded_intervals = self.client.time.interval.list(excluded_intervals)
        json_search = {
            "contextTimePeriod": interval,
            "definition": self._json_definition(),
            "exclusionPeriods": excluded_intervals,
        }
        response = self.client.session.post("/compute/search-requests", json=json_search)
        self.search_request_identifier = response.json()["id"]

    def extract_results(self):
        content = self.client.session.paginated(keys=["content"]).get(
            f"/compute/search-requests/{self.search_request_identifier}/results",
            params={"size": MAX_GET_SIZE},
        )

        results = [self.client.time.interval.from_json_search_result(data) for data in content]
        results.reverse()  # oldest result first

        # null results not part of json result, set them manually
        # convert digital tag results
        for calculation in self.calculations:
            numeric = calculation.tag.isnumeric()
            if not numeric:
                states = calculation.tag.state_dict
            for result in results:
                result.data.setdefault(calculation.key)
                if not numeric and isinstance(result.data[calculation.key], int):
                    result.data[calculation.key] = states.get(result.data[calculation.key])

        return results

    def ready(self):
        response = self.client.session.get(
            f"/compute/search-requests/{self.search_request_identifier}",
        )
        return response.json()["status"].upper() != "IN_PROGRESS"

    def get_results(self, interval="6M", excluded_intervals=None):
        self.execute(interval=interval, excluded_intervals=excluded_intervals)
        time.sleep(self.refresh_sleep)
        while not self.ready():
            time.sleep(self.refresh_sleep)
        return self.extract_results()


class SearchFactory(WorkOrganizerFactory, abc.ABC):

    @abc.abstractmethod
    def from_json_monitor(self, data):
        pass

    @abc.abstractmethod
    def from_json_monitor_nameless(self, data):
        pass
