from .client import BaseClient, Authenticated
from .session import TrendMinerSession