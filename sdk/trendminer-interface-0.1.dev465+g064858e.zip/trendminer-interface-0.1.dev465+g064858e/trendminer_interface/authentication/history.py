import pandas as pd


def unpack_response(response):
    """Unpacks response to request into a tuple

    Parameters
    ----------
    response : requests.Response
        Response to be unpacked

    Returns
    -------
    tuple
        (method, status code, url, elapsed time in s, content length)

    """
    return (
        response.request.method,
        response.status_code,
        response.request.url,
        response.elapsed.total_seconds(),
        len(response.content)
    )


def responses_to_df(responses):
    """Summarizes lists of requests responses into a DataFrame

    Used to summarize client request history

    Parameters
    ----------
    responses : list of requests.Response
        Responses to sent requests

    Returns
    -------
    pandas.DataFrame
        Contains request method, status, url, elapsed time, and content size
    """
    return pd.DataFrame.from_records(
        [unpack_response(response) for response in responses],
        columns=['method', 'status', 'url', 'time', 'size']
    )