import abc

from .history import responses_to_df


class BaseClient(abc.ABC):
    """Handles all authentication for the client. Stores the session."""

    def __init__(
            self,
            url,
            client_id,
            client_secret,
            username,
            password,
            token,
            verify,
            keep_history,
            session_type
    ):

        self.session = session_type(base_url=url, verify=verify, keep_history=keep_history)
        self.session.login(client_id=client_id,
                           client_secret=client_secret,
                           username=username,
                           password=password,
                           token=token,
                           )

    def logout(self):
        """Explicit session logout. Invalidates token."""
        self.session.logout()

    @property
    def url(self):
        """TrendMiner appliance url"""
        return self.session.base_url

    @property
    def history(self):
        """List of historic requests by the client. Empty if ``keep_history=False``"""
        return self.session.history

    @property
    def history_df(self):
        """DataFrame summarizing historic requests by the client. Empty if ``keep_history=False``"""
        return responses_to_df(self.history)

    def __repr__(self):
        return f"<< {self.__class__.__name__}" \
               f" | {self.url}" \
               f" | {self.session.token_decoded['preferred_username']} >>"


class Authenticated(abc.ABC):
    """Instances which requre authentication to the TrendMiner server

    Parameters
    ----------
    client: TrendMinerClient
        Client providing link to the appliance
    """
    def __init__(self, client):
        self.client = client

    def __repr__(self):
        return f"<< {self.__class__.__name__} >>"
