import ring
import abc
from datetime import timedelta

from . import _input as ip

from .constants import MAX_DATASOURCE_CACHE
from .base import Gettable, TrendMinerFactory, LazyLoadingClass, LazyAttribute


class DatasourceClient(abc.ABC):
    @property
    def datasource(self):
        return DatasourceFactory(client=self)


class Datasource(Gettable, LazyLoadingClass):
    endpoint = "/ds/datasources/"

    def __init__(
            self,
            client,
            identifier,
            name,
            capabilities,
            description,
            raw,
            granularity,
            connector_id,
            source_type,
            created_on,
            synced_on,
            provider_properties,
            builtin,
    ):

        super().__init__(client=client, identifier=identifier)

        self.name = name
        self.description = description
        self.capabilities = capabilities
        self.raw = raw
        self.granularity = granularity
        self.connector_id = connector_id
        self.source_type = source_type
        self.created_on = created_on
        self.synced_on = synced_on
        self.provider_properties = provider_properties
        self.builtin = builtin

    def _full_instance(self):
        return DatasourceFactory(client=self.client).from_identifier(self.identifier)

    def __json__(self):
        return self.identifier

    def __repr__(self):
        return f"<< Datasource | {self.name} | {self.source_type} >>"


class DatasourceFactory(TrendMinerFactory):
    tm_class = Datasource

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["datasourceId"],
            name=data["name"],
            capabilities=data["capabilityTypes"],
            description=data["description"],
            raw=data["onlySupportsRawValues"],
            granularity=timedelta(days=float(data["indexingGranularity"])),
            connector_id=data["connectorId"],
            source_type=data["type"],
            created_on=self.client.time.datetime(data["createOn"]),
            synced_on=self.client.time.datetime(data["syncedOn"]),
            provider_properties=data["providerTypeProperties"],
            builtin=data["builtin"],
        )

    def from_json_identifier_only(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data,
            name=LazyAttribute(),
            capabilities=LazyAttribute(),
            description=LazyAttribute(),
            raw=LazyAttribute(),
            granularity=LazyAttribute(),
            connector_id=LazyAttribute(),
            source_type=LazyAttribute(),
            created_on=LazyAttribute(),
            synced_on=LazyAttribute(),
            provider_properties=LazyAttribute(),
            builtin=LazyAttribute(),
        )

    def from_name(self, ref):
        return ip.object_match_nocase(self.all(), attribute="name", value=ref)

    def from_type(self, ref):
        return ip.object_match_nocase(self.all(), attribute="type", value=ref)

    @ring.lru(maxsize=MAX_DATASOURCE_CACHE)
    def from_identifier(self, ref):
        return super().from_identifier(ref)

    @ring.lru(maxsize=10)
    def all(self):
        return super().all()

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_name, self.from_type

