import abc

from trendminer_interface.base import LazyAttribute
from .work import WorkOrganizerObject, WorkOrganizerFactory


class FormulaClient(abc.ABC):
    @property
    def formula(self):
        return FormulaFactory(client=self)


class Formula(WorkOrganizerObject):
    content_type = "FORMULA"

    def __init__(
            self,
            client,
            formula,
            mapping,
            name,
            description,
            identifier,
            folder,
            owner,
            last_modified,
    ):
        super().__init__(
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )

        self.formula = formula
        self.mapping = mapping

    @property
    def mapping(self):
        return self._mapping

    @mapping.setter
    def mapping(self, mapping):
        if isinstance(mapping, LazyAttribute):
            self._mapping = mapping
        else:
            new_mapping = {}
            for key, value in mapping.items():
                new_mapping.update({key: self.client.tag.get(value)})
            self._mapping = new_mapping

    @property
    def tags(self):
        return list(self.mapping.values())

    def _json_data(self):
        return {
            "formula": self.formula,
            "formulaVariableLinks": [
                {
                    "variable": k,
                    "timeSeriesDefinitionId": v.identifier,
                    "shift": int(v.shift.total_seconds()),
                    "interpolationType": v.interpolation,
                    "timeSeriesName": v.name,
                }
                for k, v in self.mapping.items()
            ],
        }

    def _content_blueprint(self):
        raise NotImplementedError

    def _full_instance(self):
        return self.client.formula.from_identifier(self.identifier)

    def delete(self):
        # Rename before deleting to free the name
        self.name = "api_delete_" + self.client.time.now().isoformat()
        self.put()
        super().delete()


class FormulaFactory(WorkOrganizerFactory):
    tm_class = Formula

    def __call__(
            self,
            formula,
            mapping,
            name,
            description="",
            folder=None,
    ):
        return self.tm_class(
            client=self.client,
            formula=formula,
            mapping=mapping,
            name=name,
            description=description,
            identifier=None,
            folder=folder,
            owner=None,
            last_modified=None,
        )

    def from_json_enriched(self, data):
        mapping = {
            entry["variable"]: self.client.tag.from_json_formula(entry)
            for entry in data["data"]["formulaVariableLinks"]
        }

        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            name=data["name"],
            description=data.get("description"),
            folder=data.get("parentId", self.client.folder.root()),
            owner=self.client.user.from_json_name_only(data["owner"]),
            last_modified=data["lastModifiedDate"],
            formula=data["data"]["formula"],
            mapping=mapping,
        )
