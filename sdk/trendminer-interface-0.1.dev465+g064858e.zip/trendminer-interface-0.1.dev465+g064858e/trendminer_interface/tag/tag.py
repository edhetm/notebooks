import abc
import itertools
import numpy as np
import pandas as pd
import json
import ring

from trendminer_interface import _input as ip
from trendminer_interface.times import time_json
from trendminer_interface.compute import calculate
from trendminer_interface.base import (TrendMinerFactory, LazyLoadingClass,
                                       Gettable, LazyAttribute, HasOptions,
                                       ByFactory)
from trendminer_interface.constants import (MAX_TAG_CACHE,
                                            BUILTIN_DATASOURCES,
                                            MAX_GET_SIZE,
                                            TAG_TYPE_OPTIONS,
                                            TIMESERIES_FORM_OPTIONS,
                                            )
from trendminer_interface.exceptions import ResourceNotFound
from trendminer_interface.component import Component
from trendminer_interface.visuals import Shiftable
from trendminer_interface.datasource import DatasourceFactory, Datasource

from .index import IndexStatusFactory, IndexStatus


class TagClient(abc.ABC):
    @property
    def tag(self):
        return TagFactory(client=self)


class Tag(Gettable, Shiftable, Component, LazyLoadingClass):
    """A tag is a named stream of timeseries data

    Tags are the basis of all timeseries operations in TrendMiner. They are use throughout the applications and are
    referenced by many other classes. Tags are typically only retrieved from the appliance. It is possible to
    instantiate a new tag, though the only direct application is to create a new csv-imported tag on the appliance.

    A Tag is a 'lazy' class, meaning some attributes will only be loaded from the appliance the moment they are
    accessed. This can cause waiting times or errors at unexpected times.

    Tag instances can be created but they cannot be directly created, updated or deleted on the appliance (i.e., there are no post, put or delete methods). They can, however, be uploaded and
    deleted as imported tags via :attr:`client.io.tags`.

    Attributes
    ----------
    name : str
        tag name, must be unique
    description : str
        Provides additional info on the tag
    tag_type : str
        - **ANALOG**: numerical values, linear interpolation
        - **DISCRETE**: numerical values, step-after interpolation
        - **DIGITAL**: Selection from fixed set of string values, step-after interpolation
        - **STRING**: Any string value, step after interpolation

        STRING and DIGITAL tags are treated exactly the same in TrendMiner: a state is created for every new string tag
        value
    units : str
        Measurement physical units. Can be blank. Units are purely informative, they are not interpreted by the
        appliance.
    states : list
        Possible states for a digital or string tag. This data can be heavy to load for string tags, as they can have
        a very large number of 'states'. The index of a state in the list is the index that the state has in the
        appliance. In case a state no longer exists at a given index (i.e., the state of a digital tag has been
        removed from the historian), None is returned at that position.
    datasource : Datasource
        The datasource containing the tag

    """
    endpoint = "/ds/timeseries/"
    component_type = "TAG"

    tag_type = HasOptions(TAG_TYPE_OPTIONS)
    datasource = ByFactory(DatasourceFactory)

    def __init__(self, client, identifier, name, description, units, tag_type, datasource, states, data, color, scale,
                 shift, visible):

        Gettable.__init__(self=self, client=client, identifier=identifier)
        Shiftable.__init__(self=self, color=color, scale=scale, shift=shift, visible=visible)

        self.name = name
        self.tag_type = tag_type
        self.states = states
        self.description = description
        self.units = units
        self.datasource = datasource
        self.data = data

    @property
    def index(self):
        """Interface to tag index status

        Returns
        -------
        IndexStatus
            Interface to the index status of the tag
        """
        return IndexStatusFactory(client=self.client).from_tag(tag=self)

    def calculate(self, intervals, operation, key=None, inplace=False):
        """Perform a calculation on the given tag

        A calculation is this context is an aggregation yielding a single value per given interval.

        Parameters
        ----------
        intervals : list of Interval
            Intervals on which to perform the aggregation
        operation : str
            mean, min, max, range, start, end, delta, integral, or stdev
        key : str, optional
            Key under which the calculation result needs to be stored on the interval. Defaults to the given operation.
        inplace : bool, default False
            When True, no value is returned, but the calculation results are added to the input values under the given
            key. Otherwise, copies of the intervals are returned on which the calculations results have been added.

        Returns
        -------
        list of Interval or None
            Intervals with calculations added when :attr:`inplace=False`. When :attr:`inplace=True`, no output is given
            but the input intervals are modified in-place.
        """
        return calculate(tag=self, intervals=intervals, operation=operation, key=key, inplace=inplace)

    def isnumeric(self):
        """Check if tag is numeric

        Returns
        -------
        bool
            Whether the tag is numeric (i.e., ANALOG or DISCRETE)
        """
        return self.tag_type in ["ANALOG", "DISCRETE"]

    @property
    def interpolation_data(self):
        """Interpolation type a string, used in data calls

        Though they have the same meaning, these values are different from those used in other calls (Tag.interpolation)

        Returns
        -------
        str
            'linear' or 'step-after'
        """
        if self.tag_type == "ANALOG":
            return "linear"
        return "step-after"

    @property
    def interpolation(self):
        """Tag interpolation type

        Returns
        -------
        str
            LINEAR or STEPPED
        """
        if self.tag_type == "ANALOG":
            return "LINEAR"
        return "STEPPED"

    def state_index(self, state):
        """Returns index of given state

        Every state of a digital or string tag is assigned a unique index (an integer). For digital tags, this index
        would typically come from the historian. For a string tag, the index is assigned by TrendMiner, always taking
        the next integer value when a new string value is retrieved from the datasource.

        Parameters
        ----------
        state : str
            state for which we want to retrieve the index

        Returns
        -------
        index : int
            index of the given state in the appliance
        """
        state = ip.case_correct(state, self.states)
        return self.states.index(state)

    @property
    def state_dict(self):
        """The states given as a dict, with the index of the state as the keys"""
        return {i: state for i, state in enumerate(self.states)}

    def _full_instance(self):
        if "name" not in self.lazy:
            return self.client.tag.from_name(ref=self.name)
        else:
            return self.client.tag.from_identifier(ref=self.identifier)

    def _empty_series(self):
        """Empty series as a tag time series data placeholder

        The datatype of the series depends on the tag type

        Returns
        -------
        pd.Series
            Empty series, though with correct name, dtype, and index type
        """
        if self.isnumeric():
            dtype = "float64"
        else:
            dtype = 'str'
        return pd.Series(name=self.name, dtype=dtype, index=pd.DatetimeIndex([], tz=self.client.tz))

    @property
    def data(self):
        """Stored tag data

        Getting the data returns empty pandas.Series if no data was stored.

        For setting the data, the most straightforward way is to call :func:`~Tag.get_data` with the argument
        :attr:`inplace=True`. To append to, rather than replace existing stored data, additionally the argument
        :attr:`append=True` can be given.

        The data pandas.Series instance has the following properties:

        - **name** is equal to the tag name
        - **index** is a DatetimeIndex. If a timezone-unaware index is given by the user, it is assumed to be in the
          client timezone.
        - **dtype** is ``float64`` for numeric tags, ``str`` for string tags

        Returns
        -------
        pandas.Series
            Stored tag time series data.
        """
        if self._data is None:
            return self._empty_series()
        return self._data

    @data.setter
    def data(self, data):
        self._data = data

    # TODO: use options on form
    def get_data(self, interval="8h",
                 form="interpolated",
                 resolution=None,
                 n_intervals=None,
                 granularity="auto",
                 inplace=False,
                 append=False):
        """Retrieve time series data for the tag

        Parameters
        ----------
        interval : Interval or tuple or str
            interval for which the data needs to be retrieved
        form : {'interpolated', 'chart', 'index'}
            - **chart**: performs a plot call, returning plot-optimized points. For resolutions lower or equal to index
              resolution, this call returns index data for the tag. When resolution is higher and the tag datasource is
              not a 'raw' datasource, the request is passed on to the original datasource, in the same way that if you
              zoom in to a plot in the UX, the request is passed on to the datasource to get higher resolution data
            - **index:** similar to 'chart', in that plot optimized real datapoints are returned. The difference is that
              no data will be retrieved that is not stored in the index. No matter how high we set the resolution, the
              request is never passed on to the datasource.
            - **interpolated:** points at fixed intervals. These datapoints are obtained from interpolating the index
              data. Setting the resolution higher will retrieve more points, but always through interpolation of index
              data. A request is never passed on to the historian to get more real points. Type of the interpolation
              naturally depends on the tag type.
        resolution : datetime.timedelta or str or float, optional
            Either resolution or n_intervals needs to be given. Setting the resolution is more natural when requesting
            interpolated data. For example, ``resolution=60`` results in 1 point every minute for interpolated data,
            while it would request 1 interval per minute for chart/index data.
        n_intervals : int, optional
            Splits the interval in this number of sub-intervals for which to retrieve data. Either resolution or
            n_intervals needs to be given. Using n_intervals is more natural when requesting plot-optimized (i.e., chart
            or index) data. Every sub-interval will contain up to 4 points: min, max, start and end datapoints from the
            interval. Note that the sub-interval can return less points if the key points overlap (e.g. start value is
            also the min value), or there could even be no real datapoints stored in a given subinterval. When
            requesting interpolated data, 1 point is returned per interval.
        granularity : datetime.timedelta or str or float
            A request for large amounts of data, needs to be split up. Whe left to the default 'auto', the function will
            do this automatically. The user can also manually choose a maximal request size, given as a maximal interval
            duration.
        inplace : bool
            When True, the data is not returned, but stored under Tag.data. Default is False.
        append : bool
            When ``inplace=True``, this option controls whether the requested data needs to be appended to the data
            already stored under Tag.data, or if the data needs to be replaced. Default is False. The function
            automatically takes care of sorting the data and removing duplicate datapoints.
        """

        interval = self.client.time.interval(interval)

        if resolution is None and n_intervals is None:
            resolution = self.client.resolution

        if resolution and n_intervals:
            raise ValueError(
                'Set only resolution or number of intervals, not both'
            )

        if n_intervals is None:
            resolution = self.client.time.timedelta(resolution)
            n_intervals = int(np.ceil(interval.total_seconds() / resolution.total_seconds()))
        else:
            n_intervals = int(n_intervals)
            resolution = self.client.time.timedelta(interval.total_seconds() / n_intervals)

        form = ip.case_correct(form, value_options=TIMESERIES_FORM_OPTIONS)

        if form == "chart":
            fun = lambda p: self._data_chart(interval=p, intervals=n_intervals)
            max_points = 2e9

        elif form == "interpolated":
            interval = interval.narrow(resolution=resolution)  # round down the interval to get regular timestamps
            fun = lambda p: self._data_interp(interval=p, resolution=resolution)
            max_points = 9000

        elif form == "index":
            fun = lambda p: self._data_indexed(interval=p, intervals=n_intervals)
            max_points = 1e6

        else:
            raise ValueError(form)

        if granularity == "auto":
            try:
                granularity = self.client.time.timedelta(resolution.total_seconds() * max_points)

            # period too large
            except OverflowError:
                granularity = None

        if granularity is not None:
            granularity = self.client.time.timedelta(granularity)
            data = [fun(p) for p in interval.split(granularity)]
            data = list(itertools.chain.from_iterable(data))

        else:
            data = fun(interval)

        data = self._dict_to_data(data)

        # convert to client timezone
        data.index = data.index.tz_convert(self.client.tz)

        if inplace and append and self.data is not None:
            data = pd.concat([self.data, data]).sort_index()

        # drop duplicates
        data = data.loc[~data.index.duplicated(keep="first")]

        if not inplace:
            return data

        self.data = data

    def _data_chart(self, interval, intervals):
        """Sub-method for getting chart data"""
        payload = {
            "parameters": {"numberOfIntervals": intervals},
            "queries": [{
                "id": self.name,
                "interpolationType": self.interpolation_data,
                "shift": int(self.shift.total_seconds())
            }],
            "timePeriod": interval.__json__()
        }

        response = self.client.session.post("/compute/newFocusChart/", json=payload)

        return response.json()[0]["values"]

    def _data_interp(self, interval, resolution):
        """Sub-method for getting interpolated data"""
        payload = {
            "step": int(resolution.total_seconds()),
            "tag": {
                "id": self.identifier,
                "interpolationType": self.interpolation_data,
                "shift": int(self.shift.total_seconds()),
            },
            "timePeriod": interval.__json__(),
        }

        response = self.client.session.post("/compute/interpolatedData", json=payload)

        return response.json()["values"]

    def _data_indexed(self, interval, intervals):
        """Sub-method for getting indexed data"""
        params = {
            "endDate": time_json(interval.end),
            "interpolationType": self.interpolation_data,
            "numberOfIntervals": int(intervals),
            "startDate": time_json(interval.start),
            "timeSeriesId": self.identifier,
        }

        response = self.client.session.get("/compute/data/index", params=params)

        data = [
            json.loads(s)["points"] for s in response.content.decode().split("\n")[0:-1]
        ]

        return list(itertools.chain.from_iterable(data))

    def _dict_to_data(self, data):
        """Converts json tag data to pandas.Series

        Maps indices to string for string tags. Also takes care to return empty series in correct format if no data
        is present.
        """

        data = pd.DataFrame.from_dict(data)

        if data.empty:
            return self._empty_series()

        data["ts"] = pd.to_datetime(data["ts"])
        data.set_index("ts", inplace=True)
        data = data["value"]
        data.name = self.name

        data = data.astype(float)

        if not self.isnumeric():
            data = data.map(self.state_dict)

        return data

    def __json__(self):
        return {
            "dataReference": {
                "description": self.description,
                "id": self.identifier,
                "name": self.name,
                **Shiftable.__json__(self),
                "type": "TIME_SERIES",
            },
            "type": "DATA_REFERENCE",
        }

    def json_component(self):
        """json payload as component"""
        return {
            "reference": self.identifier,
            "type": self.component_type,
        }

    def __str__(self):
        return self.name

    def __repr__(self):
        shift_print = ""
        if self.shift.total_seconds() == 0:
            shift_print = f" | {self.shift} "
        return f"<< Tag | {self.name} {shift_print}>>"


class TagFactory(TrendMinerFactory):
    """Implements methods for tag retrieval and construction

    ``client.tag`` returns a TagFactory instance
     """
    tm_class = Tag

    def __call__(self, name, description="", units="", tag_type="ANALOG", data=None):
        """
        Creates a new Tag instance

        The main use case to create a tag directly is when we want to upload a new csv tag.

        Parameters
        ----------
        name: str
            tag name, needs to be unique on the appliance
        description: str, default ""
            description providing additional info
        units: str, default ""
            Measurement physical units
        tag_type: {'ANALOG', 'DISCRETE' or 'STRING'}
            Type of tag
        data: pandas.Series, optional
            tag timeseries data

        Returns
        -------
        Tag
            Tag with the given properties. Can be imported through the csv endpoint using ``client.io.tag.post``, but
            has no immediate use other than that.
        """
        return self.tm_class(
            client=self.client,
            name=name,
            description=description,
            units=units,
            tag_type=tag_type,
            identifier=None,
            datasource=None,
            states=None,
            data=data,
            color=None,
            scale=None,
            shift=None,
            visible=True,
        )

    @ring.lru(maxsize=MAX_TAG_CACHE)
    def from_identifier(self, ref):
        """Retrieve tag from its universally unique identifier (uuid)

        This function is cached. Tag metadata is not expected to change during the client lifetime.

        Parameters
        ----------
        ref : str
            Tag uuid

        Returns
        -------
        tag : Tag
            retrieved tag
        """
        if not ip.is_uuid(ref):  # saves us a request when using a name as ref
            raise ResourceNotFound(f"{ref} is not in UUID format")
        return super().from_identifier(ref)

    @ring.lru(maxsize=MAX_TAG_CACHE)
    def from_name(self, ref):
        """Retrieve tag from its name

        This function is cached. Tag metadata is not expected to change during the client lifetime.

        Parameters
        ----------
        ref : str
            Tag name

        Returns
        -------
        tag : Tag
            retrieved tag
        """
        params = {"tagName": ref}
        response = self.client.session.get("hps/api/tags/details", params=params)
        return self.from_json_name(response.json())

    @ring.lru(maxsize=MAX_TAG_CACHE)
    def from_attribute(self, ref):
        """Retrieve tag from an attribute.

        An attribute maps to a single tag.
        This function is cached. Tag metadata is not expected to change during the client lifetime.

        Parameters
        ----------
        ref : Attribute or str
            Attribute or reference to an Attribute

        Returns
        -------
        tag : Tag
            retrieved tag
        """
        attribute = self.client.asset.get(ref)
        return attribute.tag

    def by_rsql(self, query, params=None):
        """Search for tags using an rsql query

        Intended use is internal functions, though a user could use this method directly for a specific search.

        Parameters
        ----------
        query : str
            rsql query
        params : dict
            request parameters

        Returns
        -------
        list of Tag
            Tags meeting the search query
        """
        if params is None:
            params = {
                "size": MAX_GET_SIZE,
                "deletedAllowed": False,
            }
        data = {"query": query}
        content = self.client.session.paginated(keys=["content"]).post("ds/timeseries/search", json=data, params=params)
        return [self.from_json(data) for data in content]

    def _rsql_datasource_query(self, datasources):
        """Appends filter for specific datasources to rsql query"""
        if datasources is None:
            return ''
        identifiers = [ds.identifier for ds in self.client.datasource.list(datasources)]
        identifier_str = "','".join(identifiers)
        return f";datasource.id=in=('{identifier_str}')"

    def by_name(self, ref, datasources=None):
        """Search tags by name

        Parameters
        ----------
        ref : str
            Search query, Search query, can use '*' as wildcard
        datasources : list, optional
            List of (references to) datasources to which to limit the search. By default all accessible datasources are
            searched.

        Returns
        -------
        list of Tag
            tags meeting the search criteria
        """
        query = f"name=='{ref}'" + self._rsql_datasource_query(datasources)
        return self.by_rsql(query)

    def all(self, datasources=None):
        """Retrieve all tags

        Parameters
        ----------
        datasources : list, optional
            List of (references to) datasources to which to limit retrieval. By default, tags are retrieved from all
            accessible datasources.

        Returns
        -------
        list of Tag
            all tags in the given datasources
        """
        return self.by_name(ref="*", datasources=datasources)

    def by_description(self, ref, datasources=None):
        """Search tags by description

        Parameters
        ----------
        ref : str
            Search query, can use '*' as wildcard
        datasources : list, optional
            List of (references to) datasources to which to limit the search. By default all accessible datasources are
            searched.

        Returns
        -------
        list of Tag
            tags meeting the search criteria
        """
        query = f"description=='{ref}'" + self._rsql_datasource_query(datasources)
        return self.by_rsql(query)

    @property
    def _from_json_methods(self):
        return (
            self.from_json_component,
            self.from_json_name,
            self.from_json_identifier,
            self.from_json_calculation,
            self.from_json_search_query,
            self.from_json_current_value_tile
        )

    def from_json_identifier(self, data):
        """Assemble tag from call directly to tag UUID"""
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["name"],
            description=data.get("description", ""),
            units=data.get("units"),
            tag_type=data["type"],
            datasource=DatasourceFactory(client=self.client).from_json_identifier_only(data["datasourceId"]),
            color=None,
            scale=None,
            data=None,
            shift=None,
            states=LazyAttribute(),
            visible=True,
        )

    def from_json_name(self, data):
        """Assemble tag from call directly to tag name"""
        try:
            datasource = DatasourceFactory(client=self.client).from_json_identifier_only(data["historian"]["dbId"])
        except KeyError:
            datasource = BUILTIN_DATASOURCES[data["source"]]

        # Only call to the name provides us with the states
        try:
            state_dict = {s["Code"]: s["Name"] for s in data["States"]}
            states = [state_dict.get(i, None) for i in range(0, 1 + max(state_dict.keys()))]
        except KeyError:
            states = None

        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["name"],
            description=data.get("description", ""),
            units=data.get("units"),
            tag_type=data["Type"],
            datasource=datasource,
            color=None,
            scale=None,
            data=None,
            shift=None,
            visible=True,
            states=states,
        )

    def from_json_component(self, data):
        """Assemble tag from limited info returned from ContextHub components"""
        return self.tm_class(
            client=self.client,
            identifier=data["reference"],
            name=data["name"],
            description=data.get("description", ""),
            units=LazyAttribute(),
            tag_type=LazyAttribute(),
            datasource=LazyAttribute(),
            color=None,
            scale=None,
            data=None,
            shift=None,
            states=LazyAttribute(),
            visible=True,
        )

    def from_json_trendhub(self, data):
        """Assemble tag from limited info returned from TrendHub view"""
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["name"],
            description=data.get("description", ""),
            units=LazyAttribute(),
            tag_type=LazyAttribute(),
            datasource=LazyAttribute(),
            color=data["options"]["color"],
            scale=data["options"]["scale"],
            data=None,
            shift=data["options"]["shift"] / 1000,
            states=LazyAttribute(),
            visible=data["options"]["visible"],
        )

    def from_json_calculation(self, data):
        """Assemble tag from limited info returned from a search calculation reference"""

        # We can derive the tag type since only numerical tag calculations are possible at the moment
        tag_type = {
            "LINEAR": "ANALOG",
            "STEPPED": "DISCRETE",
        }[data["interpolationType"]]

        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["name"],
            description=LazyAttribute(),
            units=LazyAttribute(),
            tag_type=tag_type,
            datasource=LazyAttribute(),
            color=None,
            scale=None,
            data=None,
            shift=data["shift"] / 1000,
            states=LazyAttribute(),
            visible=True,
        )

    def from_json_search_query(self, data):
        """Assemble tag from limited info returned from a search query reference"""
        return self.tm_class(
            client=self.client,
            identifier=LazyAttribute(),
            name=data["tagName"],
            description=LazyAttribute(),
            units=LazyAttribute(),
            tag_type=LazyAttribute(),
            datasource=LazyAttribute(),
            color=None,
            scale=None,
            data=None,
            shift=data["shift"],
            states=LazyAttribute(),
            visible=True,
        )

    def from_json_formula(self, data):
        """Assemble tag from limited info returned from a reference in a formula"""

        # We can derive the tag type since only numerical tag calculations are possible at the moment
        # TODO: this seems wrong. We can use digital tags in a formula.
        tag_type = {
            "LINEAR": "ANALOG",
            "STEPPED": "DISCRETE",
        }[data["interpolationType"]]

        return self.tm_class(
            client=self.client,
            identifier=data["timeSeriesDefinitionId"],
            name=data["timeSeriesName"],
            description=LazyAttribute(),
            units=LazyAttribute(),
            tag_type=tag_type,
            datasource=LazyAttribute(),
            color=None,
            scale=None,
            data=None,
            shift=data["shift"],
            states=LazyAttribute(),
            visible=True,
        )

    def from_json_identifier_only(self, data):
        """Assemble tag only from its identifier. All other attributes will be lazy."""
        return self.tm_class(
            client=self.client,
            identifier=data,
            name=LazyAttribute(),
            description=LazyAttribute(),
            units=LazyAttribute(),
            tag_type=LazyAttribute(),
            datasource=LazyAttribute(),
            color=None,
            scale=None,
            data=None,
            shift=None,
            states=LazyAttribute(),
            visible=True,
        )

    def from_json_name_only(self, data):
        """Assemble tag only from its name. All other attributes will be lazy."""
        return self.tm_class(
            client=self.client,
            identifier=LazyAttribute(),
            name=data,
            description=LazyAttribute(),
            units=LazyAttribute(),
            tag_type=LazyAttribute(),
            datasource=LazyAttribute(),
            color=None,
            scale=None,
            data=None,
            shift=None,
            states=LazyAttribute(),
            visible=True,
        )

    def from_json_current_value_tile(self, data):
        """Assemble tag from limited data returned from current value tile"""
        return self.from_json_identifier_only(data["componentIdentifier"])

    def from_json_index_status(self, data):
        """Assemble tag from limited data returned from tag index status"""
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["name"],
            description=LazyAttribute(),
            units=LazyAttribute(),
            tag_type=LazyAttribute(),
            datasource=LazyAttribute(),
            color=None,
            scale=None,
            data=None,
            shift=None,
            states=LazyAttribute(),
            visible=True,
        )

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_name, self.from_attribute

    @property
    def _search_methods(self):
        return self.by_name, self.by_description

    @property
    def index(self):
        """Interface to factory for retrieving tag statuses

        Returns
        -------
        IndexStatusFactory
            Factory for retrieving tag statuses
        """
        return IndexStatusFactory(client=self.client)
