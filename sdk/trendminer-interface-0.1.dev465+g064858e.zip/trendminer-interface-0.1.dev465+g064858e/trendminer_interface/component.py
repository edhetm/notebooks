import abc


class Component(abc.ABC):
    component_type = None
