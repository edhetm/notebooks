from trendminer_interface.authentication import Authenticated

from .structure import structure_csv


class ContextIOFactory(Authenticated):

    @staticmethod
    def structure(items):
        """Puts context items in correct format to upload as csv

        Parameters
        ----------
        items : list of ContextItem
            ContextItems to be structured into a file

        Returns
        -------
        pandas.DataFrame
            DataFrame with correct structure for import. Call `.to_csv` with `index=False` to save as csv file.
        """
        return structure_csv(items)