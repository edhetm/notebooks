from trendminer_interface.authentication import Authenticated
from trendminer_interface.base import LazyAttribute
import trendminer_interface._input as ip

from .structure import structure_csv


class TagIOFactory(Authenticated):
    endpoint = "ds/imported/timeseries/"

    @staticmethod
    def structure(tags):
        """Puts tags in correct format to upload as csv

        Parameters
        ----------
        tags : list of Tag
            Tags with timeseries data added

        Returns
        -------
        pandas.DataFrame
            DataFrame with correct structure for import. Call `.to_csv` with `index_label=False` to save as csv file.
        """
        return structure_csv(tags=tags)

    def get(self):
        response = self.client.session.get(self.endpoint)
        raise NotImplementedError
        # TODO: needs tag from_json_imported

    def post(self, tags, index=True):
        """Uploads new csv tags or overwrites user's existing tags"""

        df = structure_csv(tags=tags)
        file = df.to_csv(index_label=False)
        files = {"file": ("tagdata.csv", file)}
        self.client.session.post(self.endpoint, files=files)

        # Update input tag data
        for tag in tags:
            server_tag = self.client.tag.from_name(tag.name)
            tag.identifier = server_tag.identifier
            tag.datasource = server_tag.datasource
            if not tag.isnumeric():
                tag.states = LazyAttribute()

        # Index tags if requested
        if index:
            for tag in tags:
                tag.index()

    def delete(self, tags):
        tags = self.client.tag.list(tags)

        # Need to load all imported tags and match by name to get correct identifier
        content = self.client.session.paginated(keys=["content"]).get(self.endpoint)
        for tag in tags:
            match = ip.dict_match_nocase(items=content, key="name", value=tag.name)
            self.client.session.delete(f"{self.endpoint}/{match['identifier']}")

    def delete_all(self):
        self.client.session.delete(self.endpoint)