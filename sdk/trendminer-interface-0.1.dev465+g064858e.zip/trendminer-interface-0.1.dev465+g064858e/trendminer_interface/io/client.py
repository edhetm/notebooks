from trendminer_interface.authentication import Authenticated
from .tag import TagIOFactory
from .work import WorkIOFactory
from .context import ContextIOFactory


class IOClient:
    @property
    def io(self):
        return IOFactory(client=self)


class IOFactory(Authenticated):
    @property
    def tag(self):
        return TagIOFactory(client=self.client)

    @property
    def work(self):
        return WorkIOFactory(client=self.client)

    @property
    def context(self):
        return ContextIOFactory(client=self.client)

