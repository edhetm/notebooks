from trendminer_interface.base import Gettable, TrendMinerFactory, ByFactory
from trendminer_interface.times import TimedeltaFactory
from trendminer_interface.constants import LINE_STYLES
import trendminer_interface._input as ip

import pandas as pd
import uuid


class Layer(Gettable):
    shift = ByFactory(TimedeltaFactory, "__call__")

    def __init__(
            self,
            client,
            view,
            name,
            display_timespan,
            timespan,
            base,
            visible,
            line_style,
            hidden_references,
            identifier,
            shift,
            source,
    ):
        super().__init__(client=client, identifier=identifier)
        self.view = view
        self.name = name

        # DisplayTimeSpan is what really counts, this is the original timespan as viewed when saved by the user
        # timeSpan has less meaning, as it could be completely unrelated to what the user wants to visualize. Both
        # values do not update with the live view. The actual currently displayed interval of a view is derived from
        # the saved value, the current time, and the view setttings (live, locked)
        self._display_timespan = self.client.time.interval(display_timespan)
        self._timespan = self.client.time.interval(timespan)

        self.line_style = line_style
        self.base = base
        self.visible = visible
        self.hidden_references = hidden_references
        self.name = name
        self.shift = shift
        self.source = source

    @property
    def origin(self):
        """Original interval of the layer. Can not be changed after layer has been made."""
        return self._timespan

    @property
    def interval(self):
        return self._actualize_interval(self._display_timespan)

    def _actualize_interval(self, interval):
        """Bring originally saved interval (which does not change in the backend) to the currently displayed period"""
        if self.view is None:
            return interval

        if not self.view.live:
            return interval

        shift = self.client.time.now() - self.view.base_layer._display_timespan.end

        start = interval.start
        end = interval.end + shift

        if self.view.chart.locked:
            start = start + shift

        return self.client.time.interval(start, end)

    def set_interval(self, interval, align_trailing=False):
        """Set the interval of the layer to a new value"""

        # Update the origin
        self._timespan = interval
        self.source = {"type": "MANUAL"}
        self.shift = 0

        # Update the displayed interval, depends on the base layer
        base_duration = self.view.base_layer.interval.duration
        if align_trailing:
            self._display_timespan = self.client.time.interval(interval.end - base_duration, interval.end)
        else:
            self._display_timespan = self.client.time.interval(interval.start, interval.start + base_duration)

        # If the base layer is changed, all layers need changes to the display interval
        if self.base:
            self.view._trim_layer_display_intervals()

    @property
    def line_style(self):
        if self.base:
            return "SOLID"
        return self._line_style if self._line_style != "SOLID" else "DASHED"

    @line_style.setter
    @ip.options(LINE_STYLES)
    def line_style(self, line_style):
        self._line_style = line_style

    @property
    def visible(self):
        return self._visible

    @visible.setter
    def visible(self, visible):
        self._visible = self.base or visible

    @property
    def base(self):
        return self._base

    @base.setter
    def base(self, base):
        # Reset previous base layer
        if base:
            try:
                self.view.base_layer.base = False
            except AttributeError:
                pass  # layers not instantiated yet
        self._base = base

    def get_data(self, form="interpolated", resolution=None, fill=False):
        resolution = resolution or self.client.resolution

        df = pd.concat(
            [tag.get_data(interval=self.interval, form=form, resolution=resolution) for tag in self.view.tags],
            axis=1,
        )
        if fill:
            for tag in self.view.tags:
                data = df[tag.name]
                if tag.interpolation == "STEPPED":
                    data = data.ffill()
                elif tag.interpolation == "LINEAR":
                    data = data.interpolate(method="linear")
                else:
                    raise ValueError(tag.interpolation)
                df[tag.name] = data
        return df

    def __json__(self):
        return {
            "baseLayer": self.base,
            "displayTimeSpan": self._display_timespan,
            "id": self.identifier,
            "name": self.name,
            "options": {
                "hiddenDataReferences": self.hidden_references,
                "lineStyle": self.line_style,
                "shift": int(self.shift.total_seconds()*1000),
                "visible": self.visible
            },
            "source": self.source,
            "timeSpan": self._timespan,
        }

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self.interval.start} | {self.interval.duration} >>"


class LayerFactory(TrendMinerFactory):
    tm_class = Layer

    def __init__(self, client, view):
        super().__init__(client=client)
        self.view = view

    def __call__(self, interval, base=True, name="", visible=True, line_style="SOLID"):
        return self.tm_class(
            client=self.client,
            view=self.view,
            name=name,
            display_timespan=interval,
            timespan=interval,
            base=base,
            visible=visible,
            line_style="SOLID",
            hidden_references=[],
            identifier=str(uuid.uuid4()),
            shift=0,
            source={"type": "MANUAL"},
        )

    def from_interval(self, interval):
        return self.__call__(
            interval=interval,
            base=False,
            line_style='DASHED'
        )

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            view=self.view,
            name=data["name"],
            display_timespan=data["displayTimeSpan"],
            timespan=data["timeSpan"],
            base=data["baseLayer"],
            visible=data["options"]["visible"],
            line_style=data["options"]["lineStyle"],
            hidden_references=data["options"]["hiddenDataReferences"],
            identifier=data["id"],
            shift=data["options"]["shift"]/1000,
            source=data["source"],
        )

    @property
    def _get_methods(self):
        return self.from_interval,