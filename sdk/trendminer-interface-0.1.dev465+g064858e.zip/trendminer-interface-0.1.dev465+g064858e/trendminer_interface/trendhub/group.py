from trendminer_interface.base import Serializable, TrendMinerFactory, ByFactory
from .entry import EntryFactory
from trendminer_interface.visuals.scalable import Scalable
from trendminer_interface.tag import Tag


class EntryGroup(Serializable, Scalable):
    entries = ByFactory(EntryFactory, "list")

    def __init__(self, client, entries, name, scale=None, color=None):

        Serializable.__init__(self, client=client)
        Scalable.__init__(self, color=color, scale=scale)
        self.entries = entries
        self.name = name

    @property
    def tags(self):
        return [entry if isinstance(entry, Tag) else entry.tag for entry in self.entries]

    def __json__(self):
        return {
            "group": {
                "dataReferences": [entry.__json__()["dataReference"] for entry in self.entries],
                "name": self.name,
                **Scalable.__json__(self),
            },
            "type": "GROUP",
        }

    def __repr__(self):
        return f"<< GROUP | {self.name} >>"


class EntryGroupFactory(TrendMinerFactory):
    tm_class = EntryGroup

    def __call__(self, entries, name="new", scale=None, color=None):
        return self.tm_class(
            client=self.client,
            entries=entries,
            name=name,
            scale=scale,
            color=color,
        )

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            entries=data["dataReferences"],
            name=data["name"],
            scale=data["options"]["scale"],
            color=data["options"]["color"],
        )

    @property
    def _get_methods(self):
        return ()



