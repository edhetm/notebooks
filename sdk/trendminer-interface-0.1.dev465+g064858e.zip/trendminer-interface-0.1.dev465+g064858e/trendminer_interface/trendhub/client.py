import abc

from trendminer_interface.authentication import Authenticated
from .chart import ChartingPropertiesClient
from .view import TrendHubViewFactory
from .group import EntryGroupFactory


class TrendHubClient(abc.ABC):
    @property
    def trend(self):
        return TrendHubFactory(client=self)


class TrendHubFactory(Authenticated):
    @property
    def chart(self):
        return ChartingPropertiesClient(client=self.client)

    @property
    def view(self):
        return TrendHubViewFactory(client=self.client)

    @property
    def group(self):
        return EntryGroupFactory(client=self.client)
