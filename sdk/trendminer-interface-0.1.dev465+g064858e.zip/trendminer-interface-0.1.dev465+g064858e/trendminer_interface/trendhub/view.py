from urllib.parse import urljoin

from trendminer_interface.work import WorkOrganizerObject, WorkOrganizerFactory
from trendminer_interface.tag import Tag
from trendminer_interface.asset import Attribute
from trendminer_interface.base import LazyAttribute, ByFactory
from .entry import EntryFactory
from .group import EntryGroup
from .context_interval import ContextIntervalFactory
from .layer import LayerFactory
from .chart import ChartingPropertiesFactory


class TrendHubView(WorkOrganizerObject):
    content_type = "TREND_HUB_2_VIEW"
    entries = ByFactory(EntryFactory, "list")
    chart = ByFactory(ChartingPropertiesFactory)
    context_interval = ByFactory(ContextIntervalFactory)

    # pylint: disable=too-many-arguments
    def __init__(
            self,
            client,
            identifier,
            name,
            description,
            folder,
            owner,
            last_modified,
            entries,
            layers,
            context_interval,
            live,
            chart,
            filters,
            fingerprints,
    ):

        WorkOrganizerObject.__init__(
            self,
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )

        self.live = live
        self.entries = entries
        self.chart = chart
        self.layers = layers
        self.context_interval = context_interval
        self.filters = filters
        self.fingerprints = fingerprints

    @property
    def tags(self):
        tags = []
        for entry in self.entries:
            if isinstance(entry, Tag):
                tags.append(entry)
            elif isinstance(entry, Attribute):
                tags.append(entry.tag)
            elif isinstance(entry, EntryGroup):
                for group_tag in entry.tags:
                    tags.append(group_tag)
            else:
                raise NotImplementedError
        return tags

    @property
    def layers(self):
        return self._layers

    @layers.setter
    def layers(self, layers):
        if not isinstance(layers, LazyAttribute):
            layers = LayerFactory(client=self.client, view=self).list(layers)
            if not any([layer.base for layer in layers]):
                layers[0].base = True
        self._layers = layers

    def _trim_layer_display_intervals(self, align_trailing=False):
        """Trim display intervals to the base layer. The display interval duration of secondary layers should always be
        the same as that of the base layer. This function needs to be invoked whenever layers are input manually by a
        user"""
        for layer in self.layers:
            if align_trailing:
                layer._display_timespan = \
                    self.client.time.interval(layer.interval.end - self.base_layer.interval.duration,
                                              layer.interval.end)
            else:
                layer._display_timespan = \
                    self.client.time.interval(layer.interval.start,
                                              layer.interval.start + self.base_layer.interval.duration)

    @property
    def base_layer(self):
        return [layer for layer in self.layers if layer.base][0]

    def get_data(self, form="interpolated", resolution=None, fill=False):
        return [layer.get_data(form=form, resolution=resolution, fill=fill) for layer in self.layers]

    def _json_data(self):
        return {
            "contextTimeSpan": self.context_interval.__json__(),
            "data": {
                "chartingProperties": self.chart,
                "filterEntries": self.filters,
                "fingerprintEntries": self.fingerprints,
                "layers": self.layers,
                "listEntries": self.entries,
            },
            "liveMode": self.live,
            "timeSpan": self.base_layer._display_timespan,
        }

    def _content_blueprint(self):
        raise NotImplementedError

    def _full_instance(self):
        return self.client.trend.view.from_identifier(self.identifier)

    def get_session_url(self):
        """Generate unique session url for sharing the view via link

        Returns
        -------
        str
            The url leading to the specified view
        """
        response = self.client.session.post(
            url="work/sessions",
            json={"data": self._json_data()},
        )
        session_id = response.json()["identifier"]
        return urljoin(self.client.url, f"/trendhub/#/share/{session_id}")


class TrendHubViewFactory(WorkOrganizerFactory):
    tm_class = TrendHubView

    def __call__(self,
                 entries,
                 layers,
                 context_interval='6M',
                 live=False,
                 chart=None,
                 name='New View',
                 description='',
                 folder=None,
                 align_trailing=False,
                 ):

        chart = chart or self.client.trend.chart.stacked()

        view = self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            folder=folder,
            owner=None,
            last_modified=None,
            entries=entries,
            layers=layers,
            context_interval=context_interval,
            live=live,
            chart=chart,
            filters=[],
            fingerprints=[],
        )

        view._trim_layer_display_intervals(align_trailing=align_trailing)

        return view

    def from_json_enriched(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            name=data["name"],
            description=data.get("description"),
            folder=data.get("parentId", self.client.folder.root()),
            owner=self.client.user.from_json_name_only(data["owner"]),
            last_modified=data["lastModifiedDate"],
            entries=data["data"]["data"]["listEntries"],
            layers=data["data"]["data"]["layers"],
            context_interval=data["data"]["contextTimeSpan"],
            live=data["data"]["liveMode"],
            chart=data["data"]["data"]["chartingProperties"],
            filters=data["data"]["data"]["filterEntries"],
            fingerprints=data["data"]["data"]["fingerprintEntries"],
        )

