from trendminer_interface.base import TrendMinerFactory, Serializable


class EntryFactory(TrendMinerFactory):
    tm_class = Serializable

    def __init__(self, client):
        super().__init__(client=client)

    def from_tag(self, ref):
        return self.client.tag.get(ref)

    def from_attribute(self, ref):
        return self.client.asset.get(ref)

    @property
    def _get_methods(self):
        return self.from_tag, self.from_attribute

    def from_json(self, data):
        entry_type = data["type"]

        if entry_type == "DATA_REFERENCE":
            data = data["dataReference"]

        if data["type"] == "TIME_SERIES":
            return self.client.tag.from_json_trendhub(data)

        if data["type"] == "ATTRIBUTE":
            return self.client.asset.from_json_trendhub_attribute(data)

        if entry_type == "GROUP":
            return self.client.trend.group.from_json(data=data["group"])

        raise TypeError(
            f'No handling for given entry input'
        )

