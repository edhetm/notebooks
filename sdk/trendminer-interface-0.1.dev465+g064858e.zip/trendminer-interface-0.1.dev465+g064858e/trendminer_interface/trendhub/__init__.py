from .client import TrendHubClient
from .entry import EntryFactory