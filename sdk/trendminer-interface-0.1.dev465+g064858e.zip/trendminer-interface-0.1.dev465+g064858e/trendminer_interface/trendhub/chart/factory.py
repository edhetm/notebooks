from trendminer_interface.base import TrendMinerFactory
from .scatter import ScatterChartPropertiesFactory
from .stacked import StackedChartPropertiesFactory
from .trend import TrendChartPropertiesFactory
from .base import ChartingProperties

factory_dict = {factory.tm_class.chart_type: factory for factory in [
    ScatterChartPropertiesFactory,
    StackedChartPropertiesFactory,
    TrendChartPropertiesFactory,
]}


class ChartingPropertiesFactory(TrendMinerFactory):
    tm_class = ChartingProperties

    @property
    def _get_methods(self):
        return ()

    def from_json(self, data):
        return factory_dict[data["chartType"]](client=self.client).from_json(data)
