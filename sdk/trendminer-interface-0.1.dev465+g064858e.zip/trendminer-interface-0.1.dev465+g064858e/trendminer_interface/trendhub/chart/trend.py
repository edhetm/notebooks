from .base import ChartingProperties
from trendminer_interface.base import TrendMinerFactory


class TrendChartProperties(ChartingProperties):
    chart_type = "TREND_CHART"

    def __init__(self, client, locked, y_axis_visibility, grid, filling, context):
        super().__init__(client=client, locked=locked, y_axis_visibility=y_axis_visibility)
        self.grid = grid
        self.filling = filling
        self.context = context

    def _json_settings(self):
        return {
            "trendGridLines": self.grid,
            "trendFilling": self.filling,
            "trendContextItems": self.context,
        }


class TrendChartPropertiesFactory(TrendMinerFactory):
    tm_class = TrendChartProperties

    def __init__(self, client):
        super().__init__(client=client)

    def __call__(self, locked=True, grid=False, filling=False, context=False):
        return self.tm_class(
            client=self.client,
            locked=locked,
            y_axis_visibility={},
            grid=grid,
            filling=filling,
            context=context
        )

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            locked=data["focusTimeSpanLocked"],
            y_axis_visibility=data["yAxisVisibility"],
            grid=data["chartSettings"]["stackedGridLines"],
            filling=data["chartSettings"]["stackedFilling"],
            context=data["chartSettings"]["stackedContextItems"]
        )

    @property
    def _get_methods(self):
        return ()
