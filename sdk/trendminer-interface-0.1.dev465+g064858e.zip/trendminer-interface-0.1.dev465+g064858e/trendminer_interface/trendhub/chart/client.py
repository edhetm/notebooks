from trendminer_interface.authentication import Authenticated
from .scatter import ScatterChartPropertiesFactory
from .stacked import StackedChartPropertiesFactory
from .trend import TrendChartPropertiesFactory


class ChartingPropertiesClient(Authenticated):
    @property
    def scatter(self):
        return ScatterChartPropertiesFactory(client=self.client)

    @property
    def stacked(self):
        return StackedChartPropertiesFactory(client=self.client)

    @property
    def trend(self):
        return TrendChartPropertiesFactory(client=self.client)