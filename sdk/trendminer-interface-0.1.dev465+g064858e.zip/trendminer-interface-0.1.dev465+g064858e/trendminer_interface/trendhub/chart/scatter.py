from .base import ChartingProperties
from trendminer_interface.base import TrendMinerFactory


class ScatterChartProperties(ChartingProperties):
    chart_type = "SCATTER_CHART"

    def __init__(self, client, locked, y_axis_visibility, grid, histogram, colored, correlation, mode):
        super().__init__(client=client, locked=locked, y_axis_visibility=y_axis_visibility)
        self.grid = grid
        self.histogram = histogram
        self.colored = colored,
        self.correlation = correlation,
        self.mode = mode

    def _json_settings(self):
        return {
            "scatterGridLines": self.grid,
            "scatterHistogram": self.histogram,
            "scatterColoredPoints": self.colored,
            "scatterCorrelation": self.correlation,
            "scatterMode": self.mode
        }


class ScatterChartPropertiesFactory(TrendMinerFactory):
    tm_class = ScatterChartProperties

    def __init__(self, client):
        super().__init__(client=client)

    def __call__(self, locked=True, grid=False, histogram=True, colored=True, correlation=False):
        return self.tm_class(
            client=self.client,
            locked=locked,
            y_axis_visibility={},
            grid=grid,
            histogram=histogram,
            colored=colored,
            correlation=correlation,
            mode={"type": "MULTI"},
        )

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            locked=data["focusTimeSpanLocked"],
            y_axis_visibility=data["yAxisVisibility"],
            grid=data["chartSettings"]["stackedGridLines"],
            histogram=data["chartSettings"]["scatterHistogram"],
            colored=data["chartSettings"]["scatterColoredPoints"],
            correlation=data["chartSettings"]["scatterCorrelation"],
            mode=data["chartSettings"]["scatterMode"],
        )

    @property
    def _get_methods(self):
        return ()
