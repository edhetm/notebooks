from trendminer_interface.base import Serializable, TrendMinerFactory, HasOptions, ByFactory
from trendminer_interface.constants import CONTEXT_INTERVAL_OPTIONS
from trendminer_interface.times import IntervalFactory


class ContextInterval(Serializable):
    interval = ByFactory(IntervalFactory, "__call__")
    interval_type = HasOptions(CONTEXT_INTERVAL_OPTIONS)

    def __init__(self, client, interval, interval_type, interval_range):
        super().__init__(client=client)
        self.interval = interval
        self.interval_type = interval_type
        self.interval_range = interval_range

    def __json__(self):
        payload= {
            **self.interval.__json__(),
            "type": self.interval_type,
        }

        if self.interval_range is not None:
            payload.update({"contextTimeSpanRange": self.interval_range})

        return payload


class ContextIntervalFactory(TrendMinerFactory):
    tm_class = ContextInterval

    def __init__(self, client):
        super().__init__(client=client)

    def from_interval(self, interval):
        # only allowing creation of custom timespans is sufficient
        return self.tm_class(client=self.client,
                             interval=interval,
                             interval_type="CUSTOM_CONTEXT_TIMESPAN",
                             interval_range=None,
                             )

    def from_json(self, data):
        return self.tm_class(client=self.client,
                             interval=data,
                             interval_type=data["type"],
                             interval_range=data.get("contextTimeSpanRange"),
                             )

    @property
    def _get_methods(self):
        return self.from_interval,