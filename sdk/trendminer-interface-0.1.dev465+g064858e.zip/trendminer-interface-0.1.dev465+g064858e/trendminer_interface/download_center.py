import time

from requests import RequestException
from trendminer_interface.authentication import Authenticated


class DownloadCenter(Authenticated):

    def __init__(self, client, location):
        super().__init__(client=client)
        self.location = location

    def download(self, link, max_attempts=2, wait=5):
        # Get reference
        data = {"link": link}
        response = self.client.session.post(f"{self.location}/download/generate", json=data)
        reference = response.json()["data"]

        # Download data
        attempts = 0
        success = False
        while attempts < max_attempts:
            try:
                response = self.client.session.get(f"notifications/download/public", params={"data": reference})
                success = True
                break
            except RequestException:
                attempts += 1
                time.sleep(wait)

        if not success:
            raise FileNotFoundError(link)

        return response
