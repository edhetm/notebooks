from copy import deepcopy

from trendminer_interface import _input as ip
from trendminer_interface.constants import CALCULATION_OPTIONS


def calculate(tag, intervals, operation, key=None, inplace=False):
    """Perform an aggregation operation on a tag for given intervals

    Parameters
    ----------
    tag : Tag
        The tag on which the operation happens
    operation : str
        The type of operation
    key : str, optional
        The key for which the calculation is added to the intervals. Defaults to the value given for `operation`.
    inplace : bool, default False
        Whether the results need to be added to the given interval instances in place, or if copies need to be returned
        with the results added.

    Returns
    -------
    list of Interval, or None
        Returns intervals with added values when `inplace=False`, no output if `inplace=True`.
    """
    key = key or operation
    operation = CALCULATION_OPTIONS[ip.case_correct(operation, CALCULATION_OPTIONS.keys())]
    intervals = tag.client.time.interval.list(intervals)

    interval_dict = {f"{key}{i}": interval for i, interval in enumerate(intervals)}

    payload = {
        "searchType": operation,
        "tags": [
            {
                "tagName": tag.name,
                "timePeriods": [{"key": interval_key, **interval.__json__()}
                                for interval_key, interval in interval_dict.items()],
                "shift": int(tag.shift.total_seconds()),
                "interpolationType": tag.interpolation_data,
            }
        ],
        "filters": [],
    }
    response = tag.client.session.post("/compute/calculate/", json=payload)

    if tag.isnumeric():
        mapper = lambda v: v
    else:
        mapper = lambda v: tag.state_dict[v]

    value_dict = {result["key"]: mapper(result.get("value")) for result in response.json()}

    if inplace:
        for interval_key, interval in interval_dict.items():
                interval.data.update({key: value_dict[interval_key]})

    else:
        output_intervals = []
        for interval_key, interval in interval_dict.items():
            output_interval = deepcopy(interval)
            output_interval.data.update({key: value_dict[interval_key]})
            output_intervals.append(output_interval)

        return output_intervals
