import abc

import pytz
from .factory import TimeFactory


class TimeClient(abc.ABC):
    """Implements time-related methods. Stores the timezone.
    """
    def __init__(self, tz):
        self.tz = pytz.timezone(tz) if isinstance(tz, str) else tz

    @property
    def time(self):
        return TimeFactory(client=self)
