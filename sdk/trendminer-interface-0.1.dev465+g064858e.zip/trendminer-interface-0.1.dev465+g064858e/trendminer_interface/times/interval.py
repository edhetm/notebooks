import numpy as np
import pandas as pd
import random

from collections.abc import MutableMapping

from trendminer_interface import _input as ip
from trendminer_interface.authentication import Authenticated
from trendminer_interface.base import ByFactory

from .slice import Slice
from .period import Period
from .parsers import time_json
from .datetime_factory import DatetimeFactory


class Interval(Slice, MutableMapping):
    start = ByFactory(DatetimeFactory, "__call__")
    end = ByFactory(DatetimeFactory, "__call__")

    def __init__(self, client, start, end, is_open, data=None, identifier=None):
        super().__init__(client=client, is_open=is_open)
        self.start = start
        self.end = end
        self.is_open = is_open
        self.data = data or {}
        self.identifier = identifier

    @property
    def duration(self):
        return self.end - self.start

    def narrow(self, resolution=None, inplace=False):
        """Round down start and end dates to the given resolution"""
        new_start = self.client.time.ceil(self.start, resolution=resolution)
        new_end = self.client.time.floor(self.end, resolution=resolution)

        if inplace:
            self.start = new_start
            self.end = new_end
        else:
            return self.client.time.interval(new_start, new_end, data=self.data)

    def shift(self, shift, inplace=False):
        shift = self.client.time.timedelta(shift)
        new_start = self.start + shift
        new_end = self.end + shift
        if inplace:
            self.start = new_start
            self.end = new_end
        else:
            return self.client.time.interval(new_start, new_end)

    def split(self, max_size):
        """Split the period into intervals smaller or equal to the given size"""
        max_size = self.client.time.timedelta(max_size)
        if self.duration <= max_size:
            return [self]

        intervals = int(np.ceil(self.total_seconds() / max_size.total_seconds()))
        dates = pd.date_range(
            self.start, self.end, periods=intervals+1
        )

        return [
            self.client.time.interval(start, end)
            for start, end in zip(dates[0:-1], dates[1:])
        ]

    def sample(self, duration, n=1, overlap=False, resolution=None):
        """Random sample of (smaller) random intervals from the interval"""

        resolution = self.client.time.timedelta(resolution) or self.client.resolution
        duration = self.client.time.timedelta(duration)

        # round the intervals
        interval = self.narrow(resolution=resolution)
        duration = self.client.time.round(duration)

        if overlap:
            max_value = (interval.total_seconds() - duration.total_seconds())/resolution.total_seconds()
            values = [random.randint(0, max_value) for i in range(n)]
            values.sort()
        else:
            max_value = (interval.total_seconds() - n*duration.total_seconds())/resolution.total_seconds()
            values = [random.randint(0, max_value) for i in range(n)]
            values.sort()
            values = [value + i for i, value in enumerate(values)]

        return [
            self.client.time.interval(
                interval.start + value * resolution,
                interval.start + value * resolution + duration,
                data=self.data,
            ) for value in values
        ]

    def __json__(self):
        return {"startDate": time_json(self.start), "endDate": time_json(self.end)}

    def __add__(self, other):
        other = self.client.time.timedelta(other)
        return self.client.time.interval(self.start+other, self.end+other)

    def __radd__(self, other):
        return self.__add__(other)

    def __repr__(self):
        value_str = ", ".join([f"{key}: {value}" for key, value in self.data.items()])
        if value_str:
            value_str = f" | {value_str} "
        return f"<< {type(self).__name__} | {self.start} | {self.duration} {value_str}>>"

    def __getitem__(self, item):
        return self.data.__getitem__(item)

    def __setitem__(self, key, value):
        self.data.__setitem__(key, value)

    def __delitem__(self, key):
        self.data.__delitem__(key)

    def __iter__(self):
        return self.data.__iter__()

    def __len__(self):
        return self.data.__len__()


class IntervalFactory(Authenticated):
    tm_class = Interval

    def __call__(self, *args, data=None, is_open=False):

        if len(args) == 1:
            args = args[0]

            if args is None:
                return args

            if isinstance(args, self.tm_class):
                return args

            elif isinstance(args, Period):
                return args.freeze()

            try:
                return self.from_json(args)
            except TypeError:
                pass

        try:
            if isinstance(args, str):
                dates = [date.strip() for date in args.split(",")]
                start = dates[0]
                if len(dates) == 1:
                    end = self.client.time.now()
                elif len(dates) == 2:
                    end = dates[1]
                else:
                    raise ValueError
            else:
                start = args[0]
                try:
                    end = args[1]
                except IndexError:
                    end = self.client.time.now()

            return Interval(client=self.client, start=start, end=end, data=data, is_open=is_open)

        except ValueError:
            return Period(client=self.client, duration=args).freeze()

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            start=data["startDate"],
            end=data["endDate"],
            is_open=data.get("openEnded", False),
        )

    def from_json_search_result(self, data):
        return self.tm_class(
            client=self.client,
            start=data["start"],
            end=data["end"],
            is_open=data["properties"]["openEnded"],
            identifier=data["id"],
            data=data["calculations"],
        )

    def list(self, intervals):
        intervals = ip.any_list(intervals)
        return [self.__call__(interval) for interval in intervals]

    def range(self, start=None, end=None, n_intervals=None, freq="D", normalize=False):
        """Uses pandas.date_range to generate intervals with a fixed frequency

        Generates a range over the given timespan using pandas.data_range, and then converts those into intervals by
        taking iterating over the returned datetimes. The timezone given to date_range is always the client timezone.
        More info: https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.date_range.html

        Keep in mind that the returned intervals are always interlocking. For example, requesting business days
        (freq='B') will return a series of four 1-day intervals followed by a 3-day interval (Friday-Monday).

        Attributes
        ----------
        start : datetime, optional
            Left bound for generating intervals
        end : datetime, optional
            Right bound for generating intervals
        n_intervals : int, optional
            number of intervals to generate
        freq : str or pandas.DateOffset, default 'D'
            Frequency strings can have multiples, e.g. '5H'. List of frequency aliases can be found here:
            https://pandas.pydata.org/pandas-docs/stable/user_guide/timeseries.html#timeseries-offset-aliases
        normalize : bool, default False
            Normalize start/end dates to midnight before generating date range

        Returns
        -------
        intervals : list of Interval

        """

        if n_intervals is None:
            periods = None
        else:
            periods = n_intervals + 1

        dates = pd.date_range(
            start=self.client.time.datetime(start),
            end=self.client.time.datetime(end),
            periods=periods,
            freq=freq,
            normalize=normalize,
            tz=self.client.tz,
        ).tolist()

        return [self.__call__(start, end) for start, end in zip(dates[0:-1], dates[1:])]

    def invert(self, intervals, span=None):
        """Return intervals consisting of the time between the input intervals

        The output will always be sorted from oldest to newest intervals. Overlapping input intervals are not supported.

        Parameters
        ----------
        intervals : list
            List of intervals that need to be inverted
        span : Interval, optional
            Range over which the intervals need to be inverted. When given, the time from the start of the span to the
            start of the first input interval, and the time from the last input interval to the end of the range are
            also returned as part of the inverted intervals, as long as they are not shorter than the index resolution
            (to avoid small intervals at the edges as a result of rounding). The span needs to encompass all input
            intervals. When no span is given, only the intervals inbetween the input intervals are returned as inverted
            intervals.

        Returns
        -------
        list of Interval
            inverted intervals

        """
        intervals = self.list(intervals)
        intervals = sorted(intervals, key=lambda x: x.start)

        start_times = [interval.end for interval in intervals[:-1]]
        end_times = [interval.start for interval in intervals[1:]]

        inverted_intervals = [self.__call__(start, end) for start, end in zip(start_times, end_times)]

        if span is not None:
            span = self.__call__(span)
            first_interval = self.__call__(span.start, intervals[0].start)
            last_interval = self.__call__(intervals[-1].end, span.end)
            if first_interval.duration >= self.client.resolution:
                inverted_intervals.insert(0, first_interval)
            if last_interval.duration >= self.client.resolution:
                inverted_intervals.append(last_interval)

        return inverted_intervals
