import numpy as np
import pandas as pd

from datetime import datetime, timedelta

from trendminer_interface.authentication import Authenticated

from .interval import Interval, IntervalFactory
from .period import PeriodFactory
from .datetime_factory import DatetimeFactory
from .timedelta_factory import TimedeltaFactory


class TimeFactory(Authenticated):
    def now(self):
        return datetime.now(tz=self.client.tz)

    @property
    def datetime(self):
        return DatetimeFactory(client=self.client)

    @property
    def timedelta(self):
        return TimedeltaFactory(client=self.client)

    def slice(self, *args, is_open=False):
        try:
            return self.period(duration=args[0])
        except ValueError:
            return self.interval(*args, is_open=is_open)

    @property
    def period(self):
        return PeriodFactory(client=self.client)

    @property
    def interval(self):
        return IntervalFactory(client=self.client)

    def all(self):
        return Interval(client=self.client, start=self.client.index_horizon, end=self.now(), is_open=False)

    def _round(self, time, resolution, fun):
        for getter in [self.datetime, self.timedelta, self.interval]:
            try:
                time = getter(time)
                break
            except (ValueError, AttributeError):
                pass

        resolution = self.timedelta(resolution) or self.client.resolution

        if isinstance(time, datetime):
            ts = fun(time.timestamp()/resolution.total_seconds())*resolution.total_seconds()
            return datetime.fromtimestamp(ts, tz=time.tzinfo)

        elif isinstance(time, timedelta):
            seconds = fun(time.total_seconds()/resolution.total_seconds())*resolution.total_seconds()
            return timedelta(seconds=seconds)

        elif isinstance(time, Interval):
            start = self._round(time.start, resolution=resolution, fun=fun)
            end = self._round(time.end, resolution=resolution, fun=fun)
            return self.interval(start, end)

        raise ValueError(time)

    def round(self, time, resolution=None):
        return self._round(time, resolution, round)

    def ceil(self, time, resolution=None):
        return self._round(time, resolution, np.ceil)

    def floor(self, time, resolution=None):
        return self._round(time, resolution, np.floor)
