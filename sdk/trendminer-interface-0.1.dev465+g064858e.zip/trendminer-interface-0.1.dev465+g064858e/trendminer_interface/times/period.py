from trendminer_interface.base import ByFactory
from trendminer_interface.times.slice import Slice
from trendminer_interface.authentication import Authenticated
from trendminer_interface import _input as ip
from .datetime_factory import DatetimeFactory
from .timedelta_factory import TimedeltaFactory


class Period(Slice):
    duration = ByFactory(TimedeltaFactory, "__call__")

    def __init__(self, client, duration):
        super().__init__(client, is_open=False)
        self.duration = duration

    @property
    def start(self):
        return self.end - self.duration

    @start.setter
    def start(self, start):
        start = DatetimeFactory(client=self.client)(start)
        self.duration = self.end - start

    @property
    def end(self):
        return self.client.time.now()

    def freeze(self):
        """Freeze the relative period into a regular Period instance with fixed start and end dates"""
        frozen_end = self.end
        frozen_start = frozen_end - self.duration
        return self.client.time.interval(frozen_start, frozen_end)

    def split(self, max_size):
        return self.freeze().split(max_size=max_size)

    def sample(self, duration, n=1, overlap=False, resolution=None):
        return self.freeze().sample(duration=duration, n=n, overlap=overlap, resolution=resolution)

    def __json__(self):
        return {"period": self.duration_iso}

    def __repr__(self):
        return f"<< {type(self).__name__} | {self.duration} >>"


class PeriodFactory(Authenticated):
    tm_class = Period

    def __call__(self, duration):
        if isinstance(duration, self.tm_class):
            return duration
        return self.tm_class(client=self.client, duration=duration)

    def list(self, durations):
        durations = ip.any_list(durations)
        return [self.__call__(duration) for duration in durations]