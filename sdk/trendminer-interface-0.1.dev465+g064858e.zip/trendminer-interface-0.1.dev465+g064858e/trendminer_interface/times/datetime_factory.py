import pandas as pd

from datetime import datetime

from trendminer_interface.base import LazyAttribute
from trendminer_interface.times.parsers import string_to_datetime
from trendminer_interface.authentication import Authenticated
from trendminer_interface import _input as ip


class DatetimeFactory(Authenticated):
    tm_class = datetime

    def __call__(self, t):
        if t is None or isinstance(t, LazyAttribute):
            return t

        if isinstance(t, str):
            t = string_to_datetime(t)

        if isinstance(t, (int, float)):
            t = datetime.fromtimestamp(t)

        if isinstance(t, pd.Timestamp):
            t = t.to_pydatetime()

        if t.tzinfo is None:
            t = self.client.tz.localize(t)
        else:
            t = t.astimezone(self.client.tz)

        return t

    def list(self, times):
        times = ip.any_list(times)
        return [self.__call__(t) for t in times]

