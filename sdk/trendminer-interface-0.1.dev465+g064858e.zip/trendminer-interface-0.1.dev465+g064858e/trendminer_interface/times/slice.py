import abc
import isodate

from trendminer_interface.base import Serializable


class Slice(Serializable, abc.ABC):
    def __init__(self, client, is_open):
        super().__init__(client=client)
        self.is_open = is_open

    @property
    @abc.abstractmethod
    def start(self):
        pass

    @property
    @abc.abstractmethod
    def end(self):
        pass

    @property
    @abc.abstractmethod
    def duration(self):
        pass

    @property
    def duration_iso(self):
        return isodate.duration_isoformat(self.duration)

    def total_seconds(self):
        return self.duration.total_seconds()
