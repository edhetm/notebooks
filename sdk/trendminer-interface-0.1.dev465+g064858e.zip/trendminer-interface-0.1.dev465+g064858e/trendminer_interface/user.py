import ring
import abc

from .exceptions import FromJsonError
from .constants import KEYCLOAK_REALM, ADMIN_ROLE
from . import _input as ip
from .base import Gettable, TrendMinerFactory, LazyLoadingClass, LazyAttribute
from .constants import MAX_GET_SIZE, MAX_USER_CACHE


class UserClient(abc.ABC):
    @property
    def user(self):
        return UserFactory(client=self)


class User(Gettable, LazyLoadingClass):
    endpoint = f"/auth/realms/{KEYCLOAK_REALM}/local/users/"

    def __init__(
        self,
        client,
        identifier,
        subject_type,
        name,
        admin,
        mail,
        first,
        last,
        created,
    ):
        Gettable.__init__(self, client=client, identifier=identifier)
        self.name = name
        self.first = first
        self.last = last
        self.identifier = identifier
        self.admin = admin
        self.mail = mail
        self.created = self.client.time.datetime(created) if created is not None else None
        self.subject_type = subject_type

    @property
    def everyone(self):
        return self.identifier == "Everyone"

    @property
    def blueprint(self):
        return {"name": self.name}

    def _full_instance(self):
        return self.client.user.from_name(ref=self.name)

    def __json__(self):
        return self.identifier

    def __repr__(self):
        return f"<< User | {self.name} >>"


class UserFactory(TrendMinerFactory):
    tm_class = User

    def __init__(self, client):
        super().__init__(client)

    def everyone(self):
        """Returns the 'Everyone' user needed to give all users permissions/access at once"""
        return self.tm_class(
            client=self.client,
            identifier="Everyone",
            subject_type="EVERYONE",
            name="Everyone",
            mail=None,
            admin=False,
            first=None,
            last=None,
            created=None,
        )

    def from_identifier(self, ref):
        raise NotImplementedError("User object is not gettable by identifier")

    def _query_users(self, params):
        # response = self.client.session.get(self.tm_class.endpoint, params=params)
        # user_data = response.json()["_embedded"]["content"]
        content = self.client.session.paginated(keys=["_embedded", "content"]).get(self.tm_class.endpoint, params=params)
        return [self.from_json(data=data) for data in content]

    @ring.lru(maxsize=MAX_USER_CACHE)
    def from_name(self, ref):
        if ref.lower() == "everyone":
            return self.everyone()
        params={"username": ref, "size": 10}
        return ip.object_match_nocase(self._query_users(params), attribute="name", value=ref)

    def by_any(self, ref):
        "Searches by username, first name, last name, and email"
        return self._query_users(params={"search": ref, "size": MAX_GET_SIZE})


    def all(self):
        raise NotImplementedError

    @ring.lru(maxsize=10)
    def self(self):
        return self.from_name(self.client.username)

    @property
    def _from_json_methods(self):
        return self.from_json_everyone, self.from_json_full, self.from_json_limited, self.from_json_context_filter

    def from_json_everyone(self, data):
        if data.get("subjectType", "").upper() == "EVERYONE":
            return self.everyone()
        raise FromJsonError(data)

    def from_json_full(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["userId"],
            subject_type="USER",
            name=data["username"],
            admin=ADMIN_ROLE in data["roles"],
            mail=data.get("email"),
            first=data.get("firstName"),
            last=data.get("lastName"),
            created=data.get("createdDate"),
        )

    def from_json_limited(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            subject_type="USER",
            name=data["username"],
            admin=LazyAttribute(),
            mail=LazyAttribute(),
            first=data.get("firstName"),
            last=data.get("lastName"),
            created=LazyAttribute(),
        )

    def from_json_context_filter(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["userId"],
            subject_type="USER",
            name=data["userName"],
            admin=LazyAttribute(),
            mail=LazyAttribute(),
            first=data.get("firstName"),
            last=data.get("lastName"),
            created=LazyAttribute(),
        )

    @ring.lru(maxsize=MAX_USER_CACHE)
    def from_json_name_only(self, username):
        """Create lazy object from only the name. Not part of from_json method as it would clash with get method"""
        if not isinstance(username, str):
            raise ValueError("Expecting string input")
        return self.tm_class(
            client=self.client,
            identifier=LazyAttribute(),
            subject_type="USER",
            name=username,
            admin=LazyAttribute(),
            mail=LazyAttribute(),
            first=LazyAttribute(),
            last=LazyAttribute(),
            created=LazyAttribute(),
        )

    @property
    def _get_methods(self):
        return self.from_name,

    @property
    def _search_methods(self):
        return self.by_any,
