import abc
import math
from trendminer_interface.base import Serializable, TrendMinerFactory, ByFactory
from trendminer_interface.times import TimedeltaFactory


class Tile(Serializable, abc.ABC):
    visualization_type = None
    min_size = (math.nan, math.nan)
    refresh_rate = ByFactory(TimedeltaFactory, "__call__")

    def __init__(
            self,
            client,
            content,
            x,
            y,
            title,
            refresh_rate,
            rows,
            cols,
    ):
        super().__init__(client=client)
        self.content = content
        self.title = title
        self.rows = rows
        self.cols = cols
        self.x = x
        self.y = y
        self.refresh_rate = refresh_rate

    @property
    def content(self):
        return self._content

    @content.setter
    def content(self, content):
        self._content = self._get_content(content)

    def _get_content(self, content):
        return content

    @abc.abstractmethod
    def _json_configuration(self):
        pass

    def __json__(self):
        return {
            "cols": self.cols,
            "configuration": self._json_configuration(),
            "refreshRate": int(self.refresh_rate.total_seconds()),
            "rows": self.rows,
            "title": self.title,
            "visualizationType": self.visualization_type,
            "x": self.x,
            "y": self.y,
        }


class TileFactoryBase(TrendMinerFactory, abc.ABC):
    tm_class = Tile

    def __call__(self, content, x, y, rows=4, cols=4, title="", refresh_rate="5m"):
        if (cols < self.tm_class.min_size[0]) or (rows < self.tm_class.min_size[1]):
            raise ValueError(f"Minimal size for {self.tm_class.visualization_type} tile is {self.tm_class.min_size}")
        return self.tm_class(
            client=self.client,
            content=content,
            x=x,
            y=y,
            title=title,
            refresh_rate=refresh_rate,
            rows=rows,
            cols=cols,
        )

    def _from_json_content(self, data):
        return data

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            content=self._from_json_content(data["configuration"]),
            x=data["x"],
            y=data["y"],
            title=data["title"],
            refresh_rate=data["refreshRate"],
            rows=data["rows"],
            cols=data["cols"],
            )
