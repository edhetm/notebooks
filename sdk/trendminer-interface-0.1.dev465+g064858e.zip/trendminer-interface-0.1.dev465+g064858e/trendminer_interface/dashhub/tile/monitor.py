from trendminer_interface.constants import MONITOR_TILE_OPTIONS
from trendminer_interface.base import HasOptions, AsColor
from .base import Tile, TileFactoryBase


class MonitorTile(Tile):
    visualization_type = "ALERT"
    min_size = (2, 3)

    active_icon = HasOptions(MONITOR_TILE_OPTIONS)
    inactive_icon = HasOptions(MONITOR_TILE_OPTIONS)
    active_color = AsColor()
    inactive_color = AsColor()

    def __init__(self,
                 client,
                 content,
                 active_color,
                 active_text,
                 active_icon,
                 inactive_color,
                 inactive_text,
                 inactive_icon,
                 x,
                 y,
                 title,
                 refresh_rate,
                 rows,
                 cols,
                 ):
        super().__init__(
            client=client,
            content=content,
            x=x,
            y=y,
            title=title,
            refresh_rate=refresh_rate,
            rows=rows,
            cols=cols,
        )
        self.active_color = active_color
        self.active_text = active_text
        self.active_icon = active_icon
        self.inactive_color = inactive_color
        self.inactive_text = inactive_text
        self.inactive_icon = inactive_icon

    def _get_content(self, content):
        return self.client.monitor.get(content)

    def _json_configuration(self):
        return {
            "configurationType": self.visualization_type,
            "identifier": None,
            "monitorId": int(self.content.identifier),
            "stateDefinitions": {
                "TRIGGERED": {
                    "color": self.active_color.hex_l,
                    "definition": self.active_text,
                    "icon": self.active_icon,
                },
                "NOT_TRIGGERED": {
                    "color": self.inactive_color.hex_l,
                    "definition": self.inactive_text,
                    "icon": self.inactive_icon,
                }
            },
            "type": "CURRENT_STATUS",
        }


class MonitorTileFactory(TileFactoryBase):
    tm_class = MonitorTile

    def __call__(self,
                 content,
                 x,
                 y,
                 rows=4,
                 cols=4,
                 title="",
                 refresh_rate="5m",
                 active_color="red",
                 active_text="",
                 active_icon="alert--circle",
                 inactive_color="green",
                 inactive_text="",
                 inactive_icon="circle-success",
                 ):
        return self.tm_class(client=self.client,
                             content=content,
                             active_color=active_color,
                             active_text=active_text,
                             active_icon=active_icon,
                             inactive_color=inactive_color,
                             inactive_text=inactive_text,
                             inactive_icon=inactive_icon,
                             x=x,
                             y=y,
                             title=title,
                             refresh_rate=refresh_rate,
                             rows=rows,
                             cols=cols,
                             )

    def _from_json_content(self, data):
        return self.client.monitor.from_json_identifier_only(data["monitorId"])

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            content=self._from_json_content(data["configuration"]),
            active_color=data["configuration"]["stateDefinitions"]["TRIGGERED"]["color"],
            active_text=data["configuration"]["stateDefinitions"]["TRIGGERED"]["definition"],
            active_icon=data["configuration"]["stateDefinitions"]["TRIGGERED"]["icon"],
            inactive_color=data["configuration"]["stateDefinitions"]["NOT_TRIGGERED"]["color"],
            inactive_text=data["configuration"]["stateDefinitions"]["NOT_TRIGGERED"]["definition"],
            inactive_icon=data["configuration"]["stateDefinitions"]["NOT_TRIGGERED"]["icon"],
            x=data["x"],
            y=data["y"],
            title=data["title"],
            refresh_rate=data["refreshRate"],
            rows=data["rows"],
            cols=data["cols"],
        )