import abc

from .base import Tile, TileFactoryBase


class ContextTile(Tile, abc.ABC):
    visualization_type = "CONTEXT_HUB_VIEW"
    display_mode = None
    min_size = (2, 3)

    def _get_content(self, content):
        return self.client.context.view.get(content)

    def _json_configuration(self):
        return {
            "displayMode": self.display_mode,
            "configurationType": self.visualization_type,
            "contextViewId": self.content.identifier,
        }


class ContextTileFactory(TileFactoryBase, abc.ABC):
    tm_class = ContextTile

    def _from_json_content(self, data):
        return self.client.context.view.from_json_identifier_only(data["contextViewId"])


class CounterTile(ContextTile):
    display_mode = "COUNT"


class CounterTileFactory(ContextTileFactory):
    tm_class = CounterTile


class TableTile(ContextTile):
    display_mode = "TABLE"


class TableTileFactory(ContextTileFactory):
    tm_class = TableTile


class GanttTile(ContextTile):
    display_mode = "GANTT"


class GanttTileFactory(ContextTileFactory):
    tm_class = GanttTile
