from trendminer_interface.base import TrendMinerFactory
from .trend import TrendHubViewTileFactory
from .context import CounterTileFactory, GanttTileFactory, TableTileFactory
from .monitor import MonitorTileFactory
from .base import Tile
from .external import ExternalContentTileFactory
from .value import CurrentValueTileFactory


tile_dict = {
    (
        factory.tm_class.visualization_type,
        factory.tm_class.display_mode if hasattr(factory.tm_class, "display_mode") else None
    ): factory
    for factory in [
        TrendHubViewTileFactory,
        CounterTileFactory,
        GanttTileFactory,
        TableTileFactory,
        MonitorTileFactory,
        ExternalContentTileFactory,
        CurrentValueTileFactory
    ]
}


class TileFactory(TrendMinerFactory):
    tm_class = Tile

    def from_json(self, data):
        visualization_type = data["visualizationType"]
        display_mode = data["configuration"].get("displayMode")
        return tile_dict[(visualization_type, display_mode)](client=self.client).from_json(data)
