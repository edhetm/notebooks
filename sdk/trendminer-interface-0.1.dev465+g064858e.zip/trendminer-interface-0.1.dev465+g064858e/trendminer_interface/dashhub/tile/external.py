from .base import Tile, TileFactoryBase


class ExternalContentTile(Tile):
    visualization_type = "EXTERNAL_CONTENT"
    min_size = (4, 4)

    def _json_configuration(self):
        return {
            "url": self.content
        }

class ExternalContentTileFactory(TileFactoryBase):
    tm_class = ExternalContentTile

    def _from_json_content(self, data):
        return data["url"]
