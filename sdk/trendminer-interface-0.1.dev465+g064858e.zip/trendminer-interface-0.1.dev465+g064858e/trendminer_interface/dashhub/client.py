import abc

from .dashboard import DashboardFactory


class DashHubClient(abc.ABC):
    @property
    def dashboard(self):
        return DashboardFactory(client=self)