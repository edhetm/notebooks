from trendminer_interface.base import ByFactory
from trendminer_interface.work import WorkOrganizerObject, WorkOrganizerFactory

from .tile import (TileFactory, TrendHubViewTileFactory,
                   CounterTileFactory, TableTileFactory,
                   GanttTileFactory, MonitorTileFactory,
                   ExternalContentTileFactory, CurrentValueTileFactory)


class Dashboard(WorkOrganizerObject):
    content_type = "DASHBOARD"
    tiles = ByFactory(TileFactory, "list")

    # pylint: disable=too-many-arguments
    def __init__(
            self,
            client,
            identifier,
            name,
            description,
            folder,
            owner,
            last_modified,
            tiles,
            live,
            scrollable,
    ):

        WorkOrganizerObject.__init__(
            self,
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )

        self.live = live
        self.scrollable = scrollable
        self.tiles = tiles

    def _json_data(self):
        return {
            "autoRefreshEnabled": self.live,
            "scrollable": self.scrollable,
            "tiles": self.tiles,
        }

    def _content_blueprint(self):
        raise NotImplementedError

    def _full_instance(self):
        return self.client.dashboard.from_identifier(self.identifier)


class DashboardFactory(WorkOrganizerFactory):
    tm_class = Dashboard

    def __call__(self,
                 tiles,
                 name='New Dashboard',
                 description='',
                 folder=None,
                 live=False,
                 scrollable=False,
                 ):

        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            folder=folder,
            owner=None,
            last_modified=None,
            tiles=tiles,
            live=live,
            scrollable=scrollable,
        )

    def from_json_enriched(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            name=data["name"],
            description=data.get("description"),
            folder=data.get("parentId", self.client.folder.root()),
            owner=self.client.user.from_json_name_only(data["owner"]),
            last_modified=data["lastModifiedDate"],
            live=data["data"]["autoRefreshEnabled"],
            tiles=data["data"]["tiles"],
            scrollable=data["data"]["scrollable"],
        )

    @property
    def trend(self):
        return TrendHubViewTileFactory(client=self.client)

    @property
    def count(self):
        return CounterTileFactory(client=self.client)

    @property
    def table(self):
        return TableTileFactory(client=self.client)

    @property
    def gantt(self):
        return GanttTileFactory(client=self.client)

    @property
    def monitor(self):
        return MonitorTileFactory(client=self.client)

    @property
    def external(self):
        return ExternalContentTileFactory(client=self.client)

    @property
    def values(self):
        return CurrentValueTileFactory(client=self.client)
