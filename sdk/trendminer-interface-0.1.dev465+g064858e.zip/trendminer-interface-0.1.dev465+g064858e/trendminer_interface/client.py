import pytz

from datetime import datetime
import functools

from .version import Version
from .authentication import BaseClient, TrendMinerSession
from .context import ContextClient
from .user import UserClient
from .tag.tag import TagClient
from .times import TimeClient
from .datasource import DatasourceClient
from .folder import FolderClient
from .trendhub import TrendHubClient
from .asset import AssetClient
from .search import SearchClient
from .monitor import MonitorClient
from .formula import FormulaClient
from .dashhub import DashHubClient
from .io import IOClient


class ClientCollection(
    BaseClient,
    TimeClient,
    ContextClient,
    UserClient,
    TagClient,
    DatasourceClient,
    FolderClient,
    TrendHubClient,
    AssetClient,
    SearchClient,
    MonitorClient,
    FormulaClient,
    DashHubClient,
    IOClient,
):
    """Collects clients. Used as base for TrendMinerClient and MockClient."""

    def __init__(
            self,
            url,
            client_id,
            client_secret,
            username,
            password,
            token,
            verify,
            keep_history,
            session_type,
            tz
    ):
        TimeClient.__init__(self, tz=tz)
        BaseClient.__init__(self,
                            url=url,
                            client_id=client_id,
                            client_secret=client_secret,
                            username=username,
                            password=password,
                            token=token,
                            verify=verify,
                            keep_history=keep_history,
                            session_type=session_type,
                            )

    @property
    @functools.lru_cache(maxsize=10)
    def version(self):
        params = {"timestamp": int(datetime.timestamp(datetime.utcnow()))}
        response = self.session.get("/trendhub/version", params=params)
        return Version.from_string(response.json()["release.version"])

    @property
    @functools.lru_cache(maxsize=10)
    def resolution(self):
        response = self.session.get("/ds/configurations/INDEX_RESOLUTION")
        return self.time.timedelta(float(response.json()["value"]))

    @property
    @functools.lru_cache(maxsize=10)
    def license(self):
        response = self.session.get("/confighub/license")
        return response.json()

    @property
    @functools.lru_cache(maxsize=10)
    def index_horizon(self):
        response = self.session.get("/ds/timeseries/indexhorizon")
        return self.time.datetime(response.json()["horizon"])

    @property
    @functools.lru_cache(maxsize=10)
    def username(self):
        return self.session.userinfo()['preferred_username']


class TrendMinerClient(ClientCollection):
    """Handles requests to the appliance. All methods are implemented as properties of this client.

    Parameters
    ----------
    url : str
        TrendMiner appliance url
    client_id: str, optional
        Valid client id for the given appliance. Required unless using direct token authentication.
        Learn to create client: https://trendminer.elevio.help/en/articles/143-confighub-security
    client_secret: str, optional
        Client secret matching the given client id. Required unless using direct token authentication.
    username: str, optional
        Setting username provides access to the resources of this user (e.g., saved items).
    password: str, optional
        Password matching the given username.
    token: str, optional
        Valid Keycloak token. When setting the token directly, do not set the client or user.
    verify: bool or str, default False
        Sets verify parameter for the requests to appliance. Setting to False prevents SSLError in case
        appliance SSL certificates are not valid. More info:
        https://requests.readthedocs.io/en/latest/user/advanced/#ssl-cert-verification
    keep_history: bool, default False
        Logs all requests to the appliance and the returned responses. Useful for troubleshooting.
    tz: str or pytz.BaseTzInfo, default UTC
        Client timezone. All time outputs given in client timezone. All inputs without explicit timezone are
        considered to be in the client timezone. Timezone overviews: ``pytz.all_timezones`` and
        ``pytz.common_timezones``
    """
    def __init__(self,
                 url,
                 client_id=None,
                 client_secret=None,
                 username=None,
                 password=None,
                 token=None,
                 verify=True,
                 keep_history=False,
                 tz=pytz.utc,
                 ):
        ClientCollection.__init__(
            self,
            url=url,
            client_id=client_id,
            client_secret=client_secret,
            username=username,
            password=password,
            token=token,
            verify=verify,
            keep_history=keep_history,
            session_type=TrendMinerSession,
            tz=tz
        )
