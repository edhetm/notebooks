import ring
import re
import abc

from trendminer_interface.work.work_organizer_object import WorkOrganizerObject, WorkOrganizerFactory
from trendminer_interface.base import TrendMinerFactory
from trendminer_interface.constants import FOLDER_BROWSE_SIZE, MAX_FOLDER_CACHE, WORK_ORGANIZER_CONTENT_OPTIONS
from trendminer_interface.exceptions import ResourceNotFound
from trendminer_interface.context.view import ContextHubViewFactory
from trendminer_interface.trendhub.view import TrendHubViewFactory
from trendminer_interface.search import ValueBasedSearchFactory
from trendminer_interface.formula import FormulaFactory
from trendminer_interface.dashhub import DashboardFactory

from trendminer_interface import _input as ip


class FolderClient(abc.ABC):
    @property
    def folder(self):
        return FolderFactory(client=self)


class Folder(WorkOrganizerObject):
    content_type = "FOLDER"

    def __init__(self, client, identifier, name, folder, owner, last_modified):
        super().__init__(client=client,
                         identifier=identifier,
                         name=name,
                         description=None,
                         folder=folder,
                         owner=owner,
                         last_modified=last_modified,
                         )

    def _json_data(self):
        return

    def __json__(self):
        return {
            "id": self.identifier,
            "name": self.name,
            "folder": True,
            "parentId": self.folder.identifier if self.folder else None,
        }

    def subfolders(self):
        return self.browse(folders_only=True)

    def add_folder(self, name):
        folder = self.client.folder(name=name, parent=self)
        folder.post()
        return folder

    def browse(self, included=None, excluded=None, folders_only=False):
        if excluded is None:
            excluded = ["MONITOR"]
        included = [t if isinstance(t, str) else t.content_type for t in ip.any_list(included)]
        excluded = [t if isinstance(t, str) else t.content_type for t in ip.any_list(excluded)]
        included = [ip.correct_value(t, WORK_ORGANIZER_CONTENT_OPTIONS) for t in included]
        excluded = [ip.correct_value(t, WORK_ORGANIZER_CONTENT_OPTIONS) for t in excluded]

        params = {
            "size": FOLDER_BROWSE_SIZE,
            "foldersOnly": folders_only,
            "parent": self.identifier,
        }

        if included:
            params.update({"includeTypes": included})
        elif excluded:
            params.update({"excludeTypes": excluded})

        response = self.client.session.get("/work/saveditem/browse", params=params)

        try:
            content = response.json()["_embedded"]["content"]
        except KeyError:
            content = []

        return [FolderContentFactory(client=self.client).from_json(data) for data in content]

    def get(self, name, included=None):
        """Get an object from folder by name"""
        content = self.browse(included=included)
        return ip.object_match_nocase(content, attribute="name", value=name)

    def _content_blueprint(self):
        raise NotImplementedError()

    # TODO: implement uniform strategy for cacheing and clearing the cache
    def _clear_cache(self):
        """Clear the folder getting cache every time the folder structure is changed"""
        self.client.folder.from_identifier.storage.backend.clear()

    def _put_updates(self, response):
        super()._put_updates(response)
        self._clear_cache()

    def _post_updates(self, response):
        super()._post_updates(response)
        self._clear_cache()

    def _delete_updates(self, response):
        super()._delete_updates(response)
        self._clear_cache()

    def _full_instance(self):
        raise NotImplementedError

    def __repr__(self):
        return f"<< Folder | {str(self)} >>"

    def __str__(self):
        if self.name is None:
            return "<ROOT>"
        return self.name


class FolderFactory(WorkOrganizerFactory):
    tm_class = Folder

    def __call__(self, name, parent=None):
        """Instantiate a new folder object"""
        return self.tm_class(client=self.client,
                             identifier=None,
                             name=name,
                             folder=parent,
                             owner=None,
                             last_modified=None,
                             )

    def from_json_enriched(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            name=data["name"],
            folder=data.get("parentId", self.root()),
            owner=self.client.user.from_json_name_only(data["owner"]),
            last_modified=data["lastModifiedDate"],
        )

    def root(self):
        return Folder(
            client=self.client,
            identifier=None,
            name=None,
            folder=None,
            owner=self.client.user.from_json_name_only(self.client.username),
            last_modified=None,
        )

    def from_path(self, ref, create_new=False):
        # Split in parts
        path = re.sub("^/", "", ref)
        parts = path.split("/")

        # Start at root folder
        current_folder = self.root()

        # Iterate folders
        for part in parts:
            try:
                current_folder = ip.object_match_nocase(current_folder.subfolders(), attribute="name", value=part)
            except ResourceNotFound as e:
                if create_new:
                    current_folder = current_folder.add_folder(name=part)
                else:
                    raise e

        return current_folder

    @ring.lru(maxsize=MAX_FOLDER_CACHE)
    def from_identifier(self, ref):
        return super().from_identifier(ref)

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_path


class WorkOrganizerPlaceholder(WorkOrganizerObject):
    """Placeholder for work organizer objects which have not (yet) been implemented in the SDK"""
    def __init__(self,
                 client,
                 identifier,
                 name,
                 description,
                 folder,
                 owner,
                 last_modified,
                 data,
                 content_type,
                 ):
        super().__init__(client=client,
                         identifier=identifier,
                         name=name,
                         description=description,
                         folder=folder,
                         owner=owner,
                         last_modified=last_modified,
                         )
        self.data = data
        self.content_type = content_type

    def _json_data(self):
        pass

    def _content_blueprint(self):
        pass

    def _full_instance(self):
        raise NotImplementedError

    def __repr__(self):
        return f"<< {self.content_type} (not implemented) | {self.name} >>"


class WorkOrganizerPlaceholderFactory(WorkOrganizerFactory):
    tm_class = WorkOrganizerPlaceholder

    def from_json_enriched(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            name=data["name"],
            description=data.get("description"),
            folder=data.get("parentId", self.client.folder.root()),
            owner=self.client.user.from_json_name_only(data["owner"]),
            last_modified=data["lastModifiedDate"],
            content_type=data["type"],
            data=data,
        )


work_organizer_content_dict = {factory.tm_class.content_type: factory for factory in
                               [
                                   ContextHubViewFactory,
                                   TrendHubViewFactory,
                                   FolderFactory,
                                   ValueBasedSearchFactory,
                                   FormulaFactory,
                                   DashboardFactory,
                               ]}


class FolderContentFactory(TrendMinerFactory):
    """Generates objects from any content json content found in a folder"""
    def from_json(self, data):
        content_type = data.get("type", "FOLDER")
        content = work_organizer_content_dict.get(content_type, WorkOrganizerPlaceholderFactory)
        return content(client=self.client).from_json(data)

    @property
    def _get_methods(self):
        return ()
