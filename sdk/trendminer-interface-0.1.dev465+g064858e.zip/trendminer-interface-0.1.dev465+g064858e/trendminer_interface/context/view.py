import posixpath

from trendminer_interface.base import ByFactory, HasOptions
from .filter import ContextFilterFactory

from trendminer_interface.times import time_json
from trendminer_interface.work import WorkOrganizerObject, WorkOrganizerFactory
from trendminer_interface.constants import MAX_CONTEXT_ITEM_GET_SIZE, CONTEXT_VIEW_OPTIONS

from .view_configuration import column_settings_dummy, sort_settings_dummy, gantt_settings_dummy


class ContextHubView(WorkOrganizerObject):
    content_type = "CONTEXT_LOGBOOK_VIEW"
    filters = ByFactory(ContextFilterFactory, "list")
    view_type = HasOptions(CONTEXT_VIEW_OPTIONS)

    def __init__(
        self,
        client,
        identifier,
        name,
        description,
        folder,
        owner,
        last_modified,
        filters,
        view_type,
        column_settings,
        gantt_settings,
        sort_settings,
    ):

        WorkOrganizerObject.__init__(
            self,
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )

        self.description = description
        self.name = name
        self.description = description
        self.context_items = []
        self.view_type = view_type
        self.column_settings = column_settings
        self.gantt_settings = gantt_settings
        self.sort_settings = sort_settings
        self.filters = filters

    def _full_instance(self):
        return self.client.context.view.from_identifier(self.identifier)

    def _json_search(self):
        return {
            "filters": self.filters,
            "sortProperties": ["startEventDate"],
            "sortDirection": "asc",
            "fetchSize": MAX_CONTEXT_ITEM_GET_SIZE,
        }

    def _json_delete(self):
        return {**self._json_search(), "createdBefore": time_json(self.client.time.now())}

    def _json_data(self):
        return {
            "columnSettings": self.column_settings,
            "ganttSettings": self.gantt_settings,
            "sortSettings": self.sort_settings,
            "viewType": self.view_type,
            **self._json_search(),
        }

    def _content_blueprint(self):
        raise NotImplementedError

    def search_items(self):
        content = self.client.session.continuation(keys=["content"]).post(url="/context/v2/item/search",
                                                                          json=self._json_search(),
                                                                          )

        return [self.client.context.item.from_json(item) for item in content]

    def delete_items(self):
        self.client.session.delete("/context/item/batch/filters", json=self._json_delete())


class ContextHubViewFactory(WorkOrganizerFactory):
    tm_class = ContextHubView

    def __call__(
            self,
            filters,
            name="New View",
            description="",
            folder=None,
            view_type="grid",
    ):

        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            folder=folder,
            owner=None,
            last_modified=None,
            filters=filters,
            view_type=view_type,
            column_settings=column_settings_dummy,
            sort_settings=sort_settings_dummy,
            gantt_settings=gantt_settings_dummy,
        )

    def from_identifier(self, ref):
        link = posixpath.join('/context/view', ref, "enriched")
        response = self.client.session.get(link)
        return self.from_json(response.json())

    def from_json_enriched(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            name=data["name"],
            description=data.get("description"),
            folder=data.get("parentId", self.client.folder.root()),
            owner=self.client.user.from_json_name_only(data["owner"]),
            last_modified=data["lastModifiedDate"],
            filters=data["data"]["filters"],
            view_type=data["data"]["viewType"],
            column_settings=data["data"]["columnSettings"],
            sort_settings=data["data"]["sortSettings"],
            gantt_settings=data["data"]["ganttSettings"],
        )

