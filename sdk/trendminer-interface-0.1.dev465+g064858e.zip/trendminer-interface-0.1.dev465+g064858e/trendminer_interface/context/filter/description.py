from trendminer_interface import _input as ip
from trendminer_interface.authentication import Authenticated
from trendminer_interface.context.filter.base import ContextFilterWithMode


class DescriptionFilter(ContextFilterWithMode):
    """Filter on context item description

    Attributes
    ----------
    values : list of str
        String queries to filter on the description
    """
    filter_type = "DESCRIPTION_FILTER"

    def __init__(self, client, values, mode):
        super().__init__(client=client, mode=mode)
        self.values = values

    @property
    def values(self):
        return self._values

    @values.setter
    def values(self, values):
        self._values = ip.any_list(values)

    def __json__(self):
        return {
            **super().__json__(),
            "values": self.values,
        }


class DescriptionFilterFactory(Authenticated):
    """Factory for context item description filter creation"""
    tm_class = DescriptionFilter

    def from_json(self, data):
        return self.tm_class(client=self.client, values=data.get("values"), mode=data.get("mode"))

    def __call__(self, values=None, mode=None):
        """Create new description context filter

        Parameters
        ----------
        values : list of str, optional
            Values on which to filter the description. Can take '*' as wildcard character.
        mode : str, optional
            Filter for "EMPTY" or "NON_EMPTY" description. When using mode, any given values are ignored.

        Returns
        -------
        DescriptionFilter
            Filter on context item description
        """
        return self.tm_class(client=self.client, values=values, mode=mode)
