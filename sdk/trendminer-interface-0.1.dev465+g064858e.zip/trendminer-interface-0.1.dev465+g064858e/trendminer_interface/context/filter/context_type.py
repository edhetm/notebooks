from trendminer_interface.base import ByFactory
from trendminer_interface.authentication import Authenticated
from trendminer_interface.context.filter.base.filter import ContextFilter
from trendminer_interface.context.type import ContextTypeFactory


class TypeFilter(ContextFilter):
    """Filter on context types

    Attributes
    ----------
    context_types : list
        List of (reference to) ContextType
    """
    filter_type = "TYPE_FILTER"
    context_types = ByFactory(ContextTypeFactory, "list")

    def __init__(self, client, context_types):
        super().__init__(client=client)
        self.context_types = context_types

    def __json__(self):
        return {
            **super().__json__(),
            "types": [context_type.key for context_type in self.context_types]
        }


class TypeFilterFactory(Authenticated):
    """Factory for creating context type filters"""
    tm_class = TypeFilter

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            context_types=data["typeResources"],
        )

    def __call__(self, context_types):
        """Create new context type filter


        """
        return self.tm_class(client=self.client, context_types=context_types)
