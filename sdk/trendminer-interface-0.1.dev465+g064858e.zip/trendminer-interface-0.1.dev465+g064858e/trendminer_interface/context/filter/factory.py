from trendminer_interface.base import TrendMinerFactory

from .base import ContextFilter
from .approval import ApprovalFilterFactory
from .context_type import TypeFilterFactory
from .created_by import CreatedByFilterFactory
from .components import ComponentFilterFactory
from .period import PeriodFilterFactory
from .interval import IntervalFilterFactory
from .keywords import KeywordFilterFactory
from .description import DescriptionFilterFactory
from .states import CurrentStateFilterFactory
from .field import (FieldFilterFactory,
                    NumericFieldFilterFactory,
                    StringFieldFilterFactory,
                    EnumerationFieldFilterFactory)
from .property import PropertyFieldFilterFactory
from .created_date import CreatedDateFilterFactory
from .duration import DurationFilterFactory


filter_factory_dict = {factory.tm_class.filter_type: factory for factory in
                       [
                           ApprovalFilterFactory,
                           TypeFilterFactory,
                           CreatedByFilterFactory,
                           ComponentFilterFactory,
                           PeriodFilterFactory,
                           IntervalFilterFactory,
                           KeywordFilterFactory,
                           DescriptionFilterFactory,
                           CurrentStateFilterFactory,
                           NumericFieldFilterFactory,
                           StringFieldFilterFactory,
                           EnumerationFieldFilterFactory,
                           PropertyFieldFilterFactory,
                           CreatedDateFilterFactory,
                           DurationFilterFactory,
                       ]}


class ContextFilterFactory(TrendMinerFactory):
    tm_class = ContextFilter

    @property
    def approval(self):
        return ApprovalFilterFactory(client=self.client)

    @property
    def context_types(self):
        return TypeFilterFactory(client=self.client)

    @property
    def users(self):
        return CreatedByFilterFactory(client=self.client)

    @property
    def duration(self):
        return DurationFilterFactory(client=self.client)

    @property
    def components(self):
        return ComponentFilterFactory(client=self.client)

    @property
    def period(self):
        return PeriodFilterFactory(client=self.client)

    @property
    def interval(self):
        return IntervalFilterFactory(client=self.client)

    @property
    def keywords(self):
        return KeywordFilterFactory(client=self.client)

    @property
    def description(self):
        return DescriptionFilterFactory(client=self.client)

    @property
    def states(self):
        return CurrentStateFilterFactory(client=self.client)

    @property
    def field(self):
        return FieldFilterFactory(client=self.client)

    @property
    def created_date(self):
        return CreatedDateFilterFactory(client=self.client)

    @property
    def property(self):
        return PropertyFieldFilterFactory(client=self.client)

    def from_json(self, data):
        filter_type = data["type"]
        try:
            factory = filter_factory_dict[filter_type](client=self.client)
        except (KeyError, TypeError):
            raise NotImplementedError(f"No handling for filter type {filter_type}")
        return factory.from_json(data)
