from trendminer_interface.context.filter.base.filter import ContextFilter
from trendminer_interface.authentication import Authenticated
from trendminer_interface.base import ByFactory
from trendminer_interface.user import UserFactory


class CreatedByFilter(ContextFilter):
    """Filter on context item creator

    Attributes
    ----------
    users : list of User or ClientUser
        Users on which to filter
    """
    filter_type = "CREATED_BY_FILTER"
    users = ByFactory(UserFactory, "list")

    def __init__(self, client, users):
        super().__init__(client=client)
        self.users = users

    def __json__(self):
        return {
            **super().__json__(),
            "users": self.users,
        }


class CreatedByFilterFactory(Authenticated):
    """Factory for created-by context filter creation"""
    tm_class = CreatedByFilter

    def from_json(self, data):
        return self.tm_class(client=self.client, users=data["userDetails"])

    def __call__(self, users):
        """Create new CreatedByFilter

        Parameters
        ----------
        users : list
            List of (reference to) User or ClientUser


        Returns
        -------
        CreatedByFilter
            Filter on context item creator
        """
        return self.tm_class(client=self.client, users=users)