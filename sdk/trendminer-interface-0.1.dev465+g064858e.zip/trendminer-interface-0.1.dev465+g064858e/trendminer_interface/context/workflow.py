from trendminer_interface import _input as ip

from trendminer_interface.base import Savable, QuerySearchFactory


class ContextWorkflow(Savable):
    """Python representation of TrendMiner Context Workflow"""
    endpoint = "context/workflow/"

    def __init__(self, client, identifier, name, states):

        super().__init__(client=client, identifier=identifier)

        self.name = name
        self.states = states

    def __json__(self):
        return {
            "identifier": self.identifier,
            "name": self.name,
            "states": self.states,
            "startState": self.states[0],
            "endState": self.states[-1],
        }

    def blueprint(self):
        return {
            "name": self.name,
            "states": self.states,
        }

    def __str__(self):
        return self.name

    def __repr__(self):
        return f"<< ContextWorkflow | {self.name} >>"


class ContextWorkflowFactory(QuerySearchFactory):
    tm_class = ContextWorkflow

    def __call__(self, name, states, start_state=None, end_state=None):
        return self.tm_class(client=self.client,
                             identifier=None,
                             name=name,
                             states=states,
                             )

    def by_name(self, ref):
        return self._query_search(ref=ref, search_key="name")

    def from_name(self, ref):
        return ip.object_match_nocase(self.by_name(ref), attribute="name", value=ref)

    def from_json(self, data):
        # make sure start and end states are in the correct order
        states = data["states"]
        start_state = data["startState"]
        end_state = data['endState']
        states = [start_state] + [state for state in states if state not in [start_state, end_state]] + [end_state]

        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            name=data["name"],
            states=states,
        )

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_name

    @property
    def _search_methods(self):
        return self.by_name,
