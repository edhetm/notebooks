sort_settings_dummy = [
    {
        "field": "startEventDate",
        "direction": "desc",
    }
]
