general_column_options = [
    "component",
    "type",
    "startDate",
    "endDate",
    "createdBy",
    "createdDate",
    "state",
    "description",
    "duration",
    "keywords",
    "shortKey",
]

column_settings_dummy = {
    "fields": [],
    "general": [
        {"name": "startDate", "order": 0},
        {"name": "duration", "order": 1},
        {"name": "state", "order": 2},
        {"name": "type", "order": 3},
        {"name": "component", "order": 4},
        {"name": "description", "order": 5},
    ]
}


