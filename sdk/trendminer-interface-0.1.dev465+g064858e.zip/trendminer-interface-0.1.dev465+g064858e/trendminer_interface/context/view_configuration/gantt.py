gantt_settings_dummy = {
    "displayDensity": "REGULAR",
    "expandedByDefault": False,
    "fieldsOverridingExpandSetting": [],
    "groupBy": "Type",
    "typesOverridingExpandSetting": [],
}