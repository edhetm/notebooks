import abc

from .field import ContextFieldFactory
from .workflow import ContextWorkflowFactory
from .type import ContextTypeFactory
from .item import ContextItemFactory
from .view import ContextHubViewFactory
from .filter import ContextFilterFactory

from trendminer_interface.authentication import Authenticated


class ContextClient(abc.ABC):
    @property
    def context(self):
        return ContextFactory(client=self)


class ContextFactory(Authenticated):
    @property
    def field(self):
        return ContextFieldFactory(client=self.client)

    @property
    def workflow(self):
        return ContextWorkflowFactory(client=self.client)

    @property
    def type(self):
        return ContextTypeFactory(client=self.client)

    @property
    def item(self):
        return ContextItemFactory(client=self.client)

    @property
    def view(self):
        return ContextHubViewFactory(client=self.client)

    @property
    def filter(self):
        return ContextFilterFactory(client=self.client)
