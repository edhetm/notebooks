import trendminer_interface._input as ip
from trendminer_interface.visuals.color import ColoredObject
from trendminer_interface.base import LazyLoadingClass, LazyAttribute, Savable, QuerySearchFactory, ByFactory
from .workflow import ContextWorkflowFactory
from .field import ContextFieldFactory


class ContextType(Savable, LazyLoadingClass, ColoredObject):
    endpoint = "context/type/"
    workflow = ByFactory(ContextWorkflowFactory)
    fields = ByFactory(ContextFieldFactory, "list")

    def __init__(self, client, key, name, workflow, fields, icon, color, approvals_enabled, audit_trail_enabled):
        Savable.__init__(self, client=client, identifier=key)
        ColoredObject.__init__(self, color=color)

        self.key = key
        self.name = name
        self.workflow = workflow
        self.fields = fields
        self.icon = icon
        self.approvals_enabled = approvals_enabled
        self.audit_trail_enabled = audit_trail_enabled

    def _full_instance(self):
        return self.client.context.type.from_key(self.key)

    def __json__(self):
        payload = {
            "identifier": self.key,
            "name": self.name,
            "fields": self.fields,
            "icon": self.icon,
            "color": self.api_color_ch,
            "approvalsEnabled": self.approvals_enabled,
            "auditTrailEnabled": self.audit_trail_enabled,
        }

        if self.workflow is not None:
            payload.update({"workflow": self.workflow})

        return payload

    def blueprint(self):
        return {
            "key": self.key,
            "workflow": self.workflow.name if self.workflow is not None else None,
            "fields": [field.key for field in self.fields],
            "name": self.name,
            "color": self.color.get_hex(),
            "icon": self.icon,
            "approvals_enabled": self.approvals_enabled,
            "audit_trail_enabled": self.audit_trail_enabled,
        }

    def __str__(self):
        return self.key

    def __repr__(self):
        return f"<< ContextType | {self.key} >>"


class ContextTypeFactory(QuerySearchFactory):
    tm_class = ContextType

    def __call__(self, key, name, workflow=None, fields=None, icon="information", color=None, approvals_enabled=False,
            audit_trail_enabled=False):
        return self.tm_class(client=self.client,
                             key=key,
                             name=name,
                             workflow=workflow,
                             fields=fields,
                             icon=icon,
                             color=color,
                             approvals_enabled=approvals_enabled,
                             audit_trail_enabled=audit_trail_enabled,
                             )

    def from_key(self, ref):
        return self.from_identifier(ref)

    def from_name(self, ref):
        return ip.object_match_nocase(self.by_name(ref), attribute="name", value=ref)

    def by_name(self, ref):
        return self._query_search(ref=ref, search_key="name")

    def by_key(self, ref):
        return self._query_search(ref=ref, search_key="identifier")

    @property
    def _from_json_methods(self):
        return self.from_json_full, self.from_json_context_filter

    def from_json_full(self, data):
        return self.tm_class(
            client=self.client,
            key=data["identifier"],
            workflow=data.get("workflow"),
            fields=data["fields"],
            name=data["name"],
            color="#"+data["color"],
            icon=data["icon"],
            approvals_enabled=data["approvalsEnabled"],
            audit_trail_enabled=data["auditTrailEnabled"],
        )

    def from_json_context_filter(self, data):
        return self.tm_class(
            client=self.client,
            key=data["identifier"],
            workflow=LazyAttribute(),
            fields=LazyAttribute(),
            name=data["name"],
            color="#"+data["color"],
            icon=data["icon"],
            approvals_enabled=data["approvalsEnabled"],
            audit_trail_enabled=data["auditTrailEnabled"],
        )

    @property
    def _get_methods(self):
        return self.from_key, self.from_name

    @property
    def _search_methods(self):
        return self.by_key, self.by_name,
