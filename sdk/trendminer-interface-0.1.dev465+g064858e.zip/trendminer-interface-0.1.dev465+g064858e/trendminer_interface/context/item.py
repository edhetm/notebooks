import trendminer_interface._input as ip

from trendminer_interface.tag import Tag
from trendminer_interface.component_factory import ComponentFactory
from trendminer_interface.base import Savable, TrendMinerFactory, ByFactory
from trendminer_interface.user import UserFactory
from trendminer_interface.constants import MAX_POST_SIZE

from .type import ContextTypeFactory
from .field import ContextField, ContextFieldFactory
from .event import EventFactory


search_field_keys = ['tm_monitor_id', 'tm_search_id', 'tm_search_type']


class ContextItem(Savable):
    """Python representation of TrendMiner Context Item"""
    endpoint = "context/item/"

    created_by = ByFactory(UserFactory)
    context_type = ByFactory(ContextTypeFactory)
    components = ByFactory(ComponentFactory, "list")

    def __init__(self, client, identifier, key, context_type, components, events, fields, keywords, description,
                 created_by, search_fields, sync_time):
        super().__init__(client=client, identifier=identifier)
        self.sync_time = sync_time
        self.context_type = context_type
        self.components = components
        self.events = events
        self.fields = fields
        self.keywords = keywords
        self.description = description or ""
        self.identifier = identifier
        self.key = key
        self.created_by = created_by
        self.search_fields = search_fields or {}

    @property
    def events(self):
        """Get events as list of dictionaries"""
        return self._events

    @events.setter
    def events(self, events):
        """Make Event objects from input, requires knowledge of the workflow"""
        self._events = EventFactory(client=self.client, workflow=self.context_type.workflow).list(events)

    @property
    def fields(self):
        """Get fields dictionary {field key: field value}"""
        return self._fields

    @fields.setter
    def fields(self, fields):
        """Set fields dictionary {field key: field value}"""
        fields = fields or {}
        fields = {field.key if isinstance(field, ContextField) else field: value for field, value in fields.items()}
        self._fields = fields

    @property
    def keywords(self):
        """Get list of keywords"""
        return self._keywords

    @keywords.setter
    def keywords(self, keywords):
        """Set keywords from list"""
        self._keywords = [kw.lower() for kw in ip.any_list(keywords)]

    @property
    def interval(self):
        """Get Interval object from item start and end time"""
        if not self.events:
            return None

        start_event = self.events[0]
        end_event = self.events[-1]

        if self.context_type.workflow is not None:
            is_open = end_event.state != self.context_type.workflow.states[-1]
        else:
            is_open = False

        if is_open:
            end_time = self.sync_time or self.client.time.now()
        else:
            end_time = end_event.timestamp

        return self.client.time.interval(start_event.timestamp, end_time, data=self.fields, is_open=is_open)

    def __json__(self):
        """Post/put request payload for saving/updating item"""
        return {
            "identifier": self.identifier,
            "description": self.description,
            "keywords": self.keywords,
            "type": self.context_type,
            "components": [component.json_component() for component in self.components],
            "fields": {**self.fields, **self.search_fields},
            "events": self.events,
        }

    def _post_updates(self, response):
        super()._post_updates(response)
        self.key = response.json()["shortKey"]
        self.created_by = response.json()["userDetails"]
        self.events = response.json()["events"]

    def _put_updates(self, response):
        self._sync_time = self.client.time.now()

    def approve(self):
        """Add user approval to this context item"""
        self.client.session.post(f"/context/data/{self.identifier}/approval")

    def remove_approval(self):
        """Remove user approval from this context item"""
        self.client.session.delete(f"/context/data/{self.identifier}/approval")

    def history(self):
        """Return context item history (if configured in the context type)"""
        params = {"size": 10000, "sort": "desc"}
        response = self.client.session.get(f"/context/history/{self.identifier}", params=params)
        return response.json()

    def blueprint(self):
        return {
            "context_type": self.context_type.key,
            "components": [c.name if isinstance(c, Tag) else c.path for c in self.components],
            "events": self.events,
            "fields": self.fields,
            "keywords": self.keywords,
            "description": self.description,
        }

    def __repr__(self):
        if self.interval is not None:
            return (
                f"<< ContextItem | {self.context_type.key} | {self.interval.duration} >>"
            )
        return f"<< ContextItem | {self.context_type.key} >>"


class ContextItemFactory(TrendMinerFactory):
    tm_class = ContextItem

    def __call__(self, context_type, components, events=None, description="", fields=None, keywords=None):
        return self.tm_class(client=self.client,
                             identifier=None,
                             key=None,
                             context_type=context_type,
                             components=components,
                             events=events,
                             description=description,
                             fields=fields,
                             keywords=keywords,
                             created_by=None,
                             search_fields=None,
                             sync_time=None,
                             )

    def bulk_post(self, items, per=MAX_POST_SIZE):
        payloads = [item.__json__() for item in self.list(items)]
        for i in range(0, len(items), per):
            self.client.session.post("/context/item/batch", json=payloads[i:i+per])

    def from_json(self, data):
        """Convert TrendMiner json data to ContextItem object"""

        fields = data['fields']

        search_fields = {}
        for key in search_field_keys:
            if key in fields:
                search_fields.update({key: fields.pop(key)})

        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            key=data["shortKey"],
            context_type=data["type"],
            components=data["components"],
            events=data["events"],
            fields=fields,
            keywords=data["keywords"],
            description=data.get("description"),
            created_by=data.get("userDetails"),
            search_fields=search_fields,
            sync_time=self.client.time.now()
        )

    def from_json_monitor(self, data):
        return self.tm_class(
            client=self.client,
            identifier=None,
            key=None,
            context_type=data["type"],
            components=[data["componentReference"]],
            events=None,
            fields=data["fields"],
            keywords=data["keywords"],
            description=data.get("description"),
            created_by=None,
            search_fields={},
            sync_time=None,
        )

    @property
    def _get_methods(self):
        return self.from_identifier,
