import abc
from .monitor import MonitorFactory


class MonitorClient(abc.ABC):
    @property
    def monitor(self):
        return MonitorFactory(client=self)
