from trendminer_interface.base import Savable, TrendMinerFactory
from trendminer_interface.search import ValueBasedSearchFactory
from trendminer_interface.base import LazyLoadingClass, LazyAttribute, ByFactory
from trendminer_interface.times import time_json, DatetimeFactory
from trendminer_interface import _input as ip

from .notification import WebhookNotification, EmailNotification, WhatsnewNotification, ContextItemNotification


monitor_options = {
    factory.tm_class.search_type: factory for factory in [
        ValueBasedSearchFactory
    ]
}


class Monitor(Savable, LazyLoadingClass):
    endpoint = '/hps/api/monitoring/'

    created = ByFactory(DatetimeFactory, "__call__")
    last_modified = ByFactory(DatetimeFactory, "__call__")

    def __init__(
            self,
            client,
            identifier,
            enabled,
            created,
            last_modified,
            search,
            state,
            monitor_dependency,  # is this monitor a trigger for another monitor (fingerprint deviation)
            webhook,
            email,
            whatsnew,
            context,
    ):
        Savable.__init__(self=self, client=client, identifier=identifier)

        self.enabled = enabled
        self.search = search
        self.created = created
        self.last_modified = last_modified
        self.state = state
        self.monitor_dependency = monitor_dependency
        self.webhook = webhook
        self.email = email
        self.whatsnew = whatsnew
        self.context = context

    @property
    def identifier(self):
        return self._identifier

    @identifier.setter
    def identifier(self, identifier):
        if identifier not in [None, LazyAttribute]:
            identifier = str(identifier)
        self._identifier = identifier

    @property
    def name(self):
        return self.search.name

    def post(self):
        raise NotImplementedError("Monitors are automatically created from searches. They cannot be created by POST")

    def put(self):
        super().put()
        if self.enabled:
            self.client.session.post(f"/hps/api/monitoring/status/{self.identifier}")
        else:
            self.delete()

    def delete(self):
        """This only disables the monitor, but does not remove the object"""
        self.client.session.delete(f"/hps/api/monitoring/status/{self.identifier}")

    def _full_instance(self):
        if "search" not in self.lazy:
            return MonitorFactory(client=self.client).from_search(self.search)
        else:
            return MonitorFactory(client=self.client).from_identifier(self.identifier)

    def _put_updates(self, response):
        self.last_modified = LazyAttribute()
        self.whatsnew = LazyAttribute()
        self.webhook = LazyAttribute()
        self.email = LazyAttribute()
        self.context = LazyAttribute()

    def get_results(self, limit=50):
        pass  # FIXME

    def blueprint(self):
        raise NotImplementedError

    def __json__(self):
        return {
            "contextItemNotification": self.context,
            "created": time_json(self.created),
            "emailNotification": self.email,
            "enabled": self.enabled,
            "id": int(self.identifier),
            "isMonitoringPatternDependency": self.monitor_dependency,
            "lastUpdatedDate": time_json(self.client.time.now()),
            "name": self.name,
            "searchId": self.search.identifier_monitor,
            "state": self.state,
            "type": self.search.search_type,
            "username": self.search.owner.name,
            "webhookNotification": self.webhook,
            "whatsnewNotification": self.whatsnew,
        }

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self.identifier} >>"


class MonitorFactory(TrendMinerFactory):
    tm_class = Monitor

    @property
    def _from_json_methods(self):
        return self.from_json_full, self.from_json_identifier, self.from_json_all

    def from_json_full(self, data):
        """Getting data from search ID gives full overview"""
        search_factory = monitor_options[data["type"]]
        search = search_factory(client=self.client).from_json_monitor(data)

        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            enabled=data["enabled"],
            created=data["created"],
            last_modified=data["lastUpdatedDate"],
            search=search,
            state=data["state"],
            monitor_dependency=data["isMonitoringPatternDependency"],
            webhook=WebhookNotification.from_json(
                monitor=self,
                data=data.get("webhookNotification", {"enabled": False, "url": ""})
            ),
            email=EmailNotification.from_json(monitor=self, data=data["emailNotification"]),
            whatsnew=WhatsnewNotification.from_json(monitor=self, data=data["whatsnewNotification"]),
            context=ContextItemNotification.from_json(monitor=self, data=data["contextItemNotification"]),
        )

    def from_json_all(self, data):
        """from structure when requesting overview of all monitors"""
        search_factory = monitor_options[data["type"]]
        search = search_factory(client=self.client).from_json_monitor(data)

        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            enabled=data["enabled"],
            created=data["created"],
            last_modified=data["lastUpdatedDate"],
            search=search,
            state=data["state"],
            monitor_dependency=LazyAttribute(),
            webhook=LazyAttribute(),
            email=LazyAttribute(),
            whatsnew=LazyAttribute(),
            context=LazyAttribute(),
        )

    def from_json_identifier(self, data):
        """from structure when getting monitor directly from identifier"""
        search_factory = monitor_options[data["type"]]
        search = search_factory(client=self.client).from_json_monitor_nameless(data)

        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            enabled=data["enabled"],
            created=data["created"],
            last_modified=data["lastUpdatedDate"],
            search=search,
            state=data["state"],
            monitor_dependency=LazyAttribute(),
            webhook=WebhookNotification.from_json(
                monitor=self,
                data=data.get("webhookNotification", {"enabled": False, "url": ""})
            ),
            email=EmailNotification.from_json(monitor=self, data=data["emailNotification"]),
            whatsnew=WhatsnewNotification.from_json(monitor=self, data=data["whatsnewNotification"]),
            context=ContextItemNotification.from_json(monitor=self, data=data["contextItemNotification"]),
        )

    def from_json_identifier_only(self, data):
        """create instance from only the identifier"""
        return self.tm_class(
            client=self.client,
            identifier=data,
            enabled=LazyAttribute(),
            created=LazyAttribute(),
            last_modified=LazyAttribute(),
            search=LazyAttribute(),
            state=LazyAttribute(),
            monitor_dependency=LazyAttribute(),
            webhook=LazyAttribute(),
            email=LazyAttribute(),
            whatsnew=LazyAttribute(),
            context=LazyAttribute(),
        )

    def from_search(self, search):
        search = self.client.search.get(search)
        response = self.client.session.get(f"hps/api/monitoring/bySearchId/{search.identifier_monitor}")
        monitor = self.from_json_full(response.json())
        monitor.search = search
        return monitor

    def overview(self, since):
        params = {
            "since": time_json(self.client.time.datetime(since))
        }
        response = self.client.session.get("/hps/api/monitoring/overview", params=params)
        active_monitors = self.all(active_only=True)
        return {
            ip.object_match_nocase(active_monitors, "identifier", str(entry["id"])): entry["numberOfResults"]
            for entry in response.json()["overview"]
        }

    def from_identifier(self, ref):
        ref = str(ref)
        return super().from_identifier(ref)

    def all(self, active_only=True):
        params = {
            "filterOnlyActiveMonitors": active_only,
            "doNotRetrieveTags": True,
        }
        response = self.client.session.get(self.tm_class.endpoint, params=params)
        return [self.from_json_all(data) for data in response.json()]

    def from_name(self, ref):
        return ip.object_match_nocase(self.all(active_only=False), "name", ref)

    @property
    def _get_methods(self):
        return self.from_search, self.from_identifier, self.from_name
