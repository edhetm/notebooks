from .base import Notification


class WebhookNotification(Notification):
    def __init__(self, monitor, enabled, enabled_at, url):
        super().__init__(monitor, enabled, enabled_at)
        self.url = url

    @classmethod
    def from_json(cls, monitor, data):
        return cls(
            monitor=monitor,
            enabled=data["enabled"],
            enabled_at=data.get("enabledAt"),
            url=data["url"],
        )

    def __json__(self):
        return {
            **super().__json__(),
            "url": self.url,
        }