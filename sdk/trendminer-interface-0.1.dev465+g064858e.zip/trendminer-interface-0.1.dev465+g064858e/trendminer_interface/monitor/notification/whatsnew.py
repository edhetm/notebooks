from .base import Notification
from trendminer_interface.times import time_json, DatetimeFactory
from trendminer_interface.base import ByFactory


class WhatsnewNotification(Notification):
    access_date = ByFactory(DatetimeFactory, "__call__")

    def __init__(self, monitor, enabled, enabled_at, access_date):
        super().__init__(monitor, enabled, enabled_at)
        self.access_date = access_date

    @classmethod
    def from_json(cls, monitor, data):
        return cls(
            monitor=monitor,
            enabled=data["enabled"],
            enabled_at=data["enabledAt"],
            access_date=data["whatsNewSearchAccessDate"],
        )

    def __json__(self):
        return {
            **super().__json__(),
            "whatsNewSearchAccessDate": time_json(self.access_date),
        }