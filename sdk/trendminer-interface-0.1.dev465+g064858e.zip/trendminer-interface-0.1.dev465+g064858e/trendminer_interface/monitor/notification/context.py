from .base import Notification


class ContextItemNotification(Notification):
    def __init__(self, monitor, enabled, enabled_at, item):
        super().__init__(monitor, enabled, enabled_at)
        self.item = item

    @classmethod
    def from_json(cls, monitor, data):
        if data["componentType"] is None:
            item = None
        else:
            item = monitor.client.context.item.from_json_monitor(data)
        return cls(
            monitor=monitor,
            enabled=data["enabled"],
            enabled_at=data["enabledAt"],
            item=item,
        )

    def _json_item(self):
        return {
            "componentReference": self.item.components[0].identifier,
            "componentType": self.item.components[0].component_type,
            "description": self.item.description,
            "fields": self.item.fields,
            "keywords": self.item.keywords,
            "type": self.item.context_type.key,
        }

    @staticmethod
    def _json_item_dummy():
        return {
            "componentReference": None,
            "componentType": None,
            "description": "",
            "fields": {},
            "keywords": [],
            "type": None,
        }

    def __json__(self):
        if self.item is None:
            item_payload = self._json_item_dummy()
        else:
            item_payload = self._json_item()

        return {
            **super().__json__(),
            **item_payload,
        }