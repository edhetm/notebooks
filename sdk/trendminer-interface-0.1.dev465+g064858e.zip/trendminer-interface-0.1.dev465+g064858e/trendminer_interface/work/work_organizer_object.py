import abc
import re

from trendminer_interface.constants import WORK_ORGANIZER_SHARE_OPTIONS
from trendminer_interface.base import Savable, LazyLoadingClass, LazyAttribute
from trendminer_interface.access import AccessRuleFactory
from trendminer_interface.base import TrendMinerFactory, ByFactory
from trendminer_interface.times import DatetimeFactory
from trendminer_interface.user import UserFactory
from trendminer_interface import _input as ip


class WorkOrganizerObject(Savable, LazyLoadingClass, abc.ABC):
    endpoint = "/work/saveditem/"
    content_type = None
    last_modified = ByFactory(DatetimeFactory, "__call__")
    owner = ByFactory(UserFactory)

    def __init__(self, client, identifier, name, description, folder, owner, last_modified):
        Savable.__init__(self=self, client=client, identifier=identifier)
        self.name = name
        self.description = description
        self.folder = folder
        self.owner = owner
        self.last_modified = last_modified

    @property
    def folder(self):
        # TODO: avoids circular import of Folder. Clean way to avoid and use descriptor?
        self._folder = self.client.folder.get(self._folder)
        return self._folder

    @folder.setter
    def folder(self, folder):
        self._folder = folder

    def _post_updates(self, response):
        super()._post_updates(response)
        self.last_modified = response.json()["lastModifiedDate"]
        self.owner = response.json()["ownerUserDetails"]
        if self.folder is None:
            self.folder = self.client.folder.root()

    def _put_updates(self, response):
        super()._put_updates(response)
        self.last_modified = response.json()["lastModifiedDate"]

    @property
    def access(self):
        return AccessRuleFactory(parent=self,
                                 endpoint=f"{self.link}/accessrule",
                                 option_dict=WORK_ORGANIZER_SHARE_OPTIONS)

    @classmethod
    def is_folder(cls):
        return cls.content_type == "FOLDER"

    @property
    @abc.abstractmethod
    def _content_blueprint(self):
        pass

    @abc.abstractmethod
    def _json_data(self):
        pass

    def __json__(self):
        return {
            "identifier": self.identifier,
            "name": self.name,
            "description": self.description,
            "type": self.content_type,
            "folder": self.is_folder(),
            "parentId": self.folder.identifier if self.folder else None,
            "data": self._json_data()
        }

    @property
    def blueprint(self):
        return {
            "name": self.name,
            "description": self.description,
            "path": self.folder.path,
            **self._content_blueprint,
        }

    def __repr__(self):
        # Do not try to load the object if the name is lazy (happens when getting instance from DashHub tile)
        if "name" not in self.lazy:
            ref = self.name
        else:
            ref = self.identifier
        return f"<< {type(self).__name__} | {ref} >>"


class WorkOrganizerFactory(TrendMinerFactory, abc.ABC):

    def from_path(self, ref):
        # Split in parts
        path = re.sub("^/", "", ref)
        parts = path.split("/")

        # Start at root folder
        current_folder = self.client.folder.root()

        # Iterate folders
        for part in parts[0:-1]:
            current_folder = ip.object_match_nocase(current_folder.subfolders(), attribute="name", value=part)

        return current_folder.get(parts[-1], included=[self.tm_class])

    def from_json_work_organizer(self, data):
        kwargs = {
            "client": self.client,
            "identifier": data["identifier"],
            "name": data["name"],
            "description": data.get("description"),
            "folder": data.get("parentId", self.client.folder.root()),
            "owner": data["ownerUserDetails"],
            "last_modified": data["lastModifiedDate"],
        }

        for kw in self.tm_class.__init__.__code__.co_varnames:
            if kw in kwargs or kw == "self":
                continue
            kwargs.update({kw: LazyAttribute()})

        return self.tm_class(**kwargs)

    @abc.abstractmethod
    def from_json_enriched(self, data):
        pass

    def from_json_identifier_only(self, data):
        kwargs = {
            "client": self.client,
            "identifier": data,
        }

        for kw in self.tm_class.__init__.__code__.co_varnames:
            if kw in kwargs or kw == "self":
                continue
            kwargs.update({kw: LazyAttribute()})

        return self.tm_class(**kwargs)

    @property
    def _from_json_methods(self):
        return self.from_json_enriched, self.from_json_work_organizer

    def by_name(self, ref):
        params = {
            "query": ref,
            "includeTypes": self.tm_class.content_type,
            "includeData": True,
        }

        content = self.client.session.paginated(keys=["_embedded", "content"]).get(
            url="work/saveditem/search",
            params=params
        )

        return [self.from_json_enriched(data) for data in content]

    def all(self):
        return self.search("*")

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_path

    @property
    def _search_methods(self):
        return self.by_name,
