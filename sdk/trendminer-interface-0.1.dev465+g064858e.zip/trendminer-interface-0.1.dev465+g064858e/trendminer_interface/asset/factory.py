from trendminer_interface.base import TrendMinerFactory, LazyAttribute, ByFactory
from trendminer_interface import _input as ip
from trendminer_interface.constants import MAX_GET_SIZE
from trendminer_interface.exceptions import AmbiguousResource, ResourceNotFound, FromJsonError
from trendminer_interface.tag import TagFactory

from .node import Node
from .asset import Asset, RootAsset
from .attribute import Attribute
from .framework import AssetFrameworkFactory


# TODO: needs handling for json 'permissions': ['ASSET_NO_PERMISSIONS']. Throws from_path error for non-admin user
class AssetFactory(TrendMinerFactory):
    """Implements methods for Asset and Attribute retrieval

    ``client.asset`` returns an AssetFactory instance
     """
    tm_class = Node

    @property
    def framework(self):
        """Interface to factory for retrieving and creating asset frameworks

        Returns
        -------
        AssetFrameworkFactory
            Factory for retrieving retrieving and creating asset frameworks
        """
        return AssetFrameworkFactory(client=self.client)

    @property
    def _from_json_methods(self):
        return (
            self.from_json_af,
            self.from_json_trendhub_attribute,
            self.from_json_deleted,
            self.from_json_current_value_tile
        )

    def from_json_trendhub_attribute(self, data):
        return Attribute(
            client=self.client,
            name=data["name"],
            description=data.get("description"),
            identifier=data["id"],
            source=LazyAttribute(),
            template=LazyAttribute(),
            identifier_template=LazyAttribute(),
            identifier_external=LazyAttribute(),
            path_hex=data["path"],
            tag=LazyAttribute(),
            color=data["options"]["color"],
            scale=data["options"]["scale"],
            shift=data["options"]["shift"]/1000,
            visible=data["options"]["visible"],
        )

    def from_json_af(self, data):
        if data["type"] == Asset.component_type:
            return Asset(
                client=self.client,
                name=data["name"],
                description=data.get("description"),
                identifier=data["identifier"],
                source=data["source"],
                template=data.get("template"),
                identifier_template=data.get("templateId"),
                identifier_external=data.get("externalId"),
                path_hex=data["paths"][0],
            )

        elif data["type"] == Attribute.component_type:
            try:
                tag = data["timeSeriesDefinition"]  # For csv attributes, this is a json with tag info
            except KeyError:
                tag = TagFactory(client=self.client).from_json_name_only(data["data"])  # for PI AF, it's only a name

            return Attribute(
                client=self.client,
                name=data["name"],
                description=data.get("description"),
                identifier=data["identifier"],
                source=data["source"],
                template=data.get("template"),
                identifier_template=data.get("templateId"),
                identifier_external=data.get("externalId"),
                path_hex=data["paths"][0],
                tag=tag,  # under 'data' for PI AF attributes
                color=None,
                scale=None,
                shift=0,
                visible=True,
            )

        else:
            raise ValueError(data["type"])

    def from_json_current_value_tile(self, data):
        if data["type"] != Attribute.component_type:
            raise FromJsonError
        return Attribute(
            client=self.client,
            name=LazyAttribute(),
            description=LazyAttribute(),
            identifier=data["componentIdentifier"],
            source=LazyAttribute(),
            template=LazyAttribute(),
            identifier_template=LazyAttribute(),
            identifier_external=LazyAttribute(),
            path_hex=data["path"],
            tag=LazyAttribute(),
            color=None,
            scale=None,
            shift=None,
            visible=None,
        )

    def from_json_deleted(self, data):
        if not data.get("deleted"):
            raise FromJsonError

        if data["type"] == Asset.component_type:
            return Asset(
                client=self.client,
                name=data["name"],
                description=data.get("description"),
                identifier=data["identifier"],
                source=None,
                template=data.get("template"),
                identifier_template=data.get("templateId"),
                identifier_external=data.get("externalId"),
                path_hex=None,
            )

        elif data["type"] == Attribute.component_type:
            return Attribute(
                client=self.client,
                name=data["name"],
                description=data.get("description"),
                identifier=data["identifier"],
                source=None,
                template=data.get("template"),
                identifier_template=data.get("templateId"),
                identifier_external=data.get("externalId"),
                path_hex=None,
                tag=data.get("timeSeriesDefinition"),
                color=None,
                scale=None,
                shift=0,
                visible=True,
            )

    def root(self):
        """Artificial root instance

        Returns
        -------
        RootAsset
        """
        return RootAsset(client=self.client)

    def from_path(self, ref):
        """Returns Asset or Attribute from path

        Parameters
        ----------
        ref : str
            Human readable path as text, e.g. "my_asset/my_subasset/my_attribute"

        Returns
        -------
        Asset or Attribute
            The asset or attribute at the given path
        """
        asset_name_list = [name for name in ref.split("/") if name != ""]
        asset = self.root()
        for asset_name in asset_name_list:
            asset = ip.object_match_nocase(asset.children, attribute="name", value=asset_name)
        return asset

    def from_path_hex(self, ref):
        """Returns Asset or Attribute from path with hex values

        Used for internal retrieval of Assets or Attributes

        Parameters
        ----------
        ref : str
            Hexagonal path as string, e.g. "0000025e.0000025f.00000260"

        Returns
        -------
        Asset or Attribute
            The asset or attribute at the given path
        """
        params = {"path": ref}
        response = self.client.session.get(self.tm_class.endpoint, params=params)
        content = response.json()["content"]
        if len(content) > 1:
            raise AmbiguousResource(ref)
        if len(content) == 0:
            raise ResourceNotFound(ref)
        return self.from_json(content[0])

    def by_rsql(self, query):
        """Executes RSQL query to the assets database

        Used by other functions to retrieve assets, though use cases could exist where a custom query is input directly.

        Parameters
        ----------
        query: str
            RSQL query, e.g. "name==my_asset"

        Returns
        -------
        List[Union[Asset, Attribute]]
            List of assets and attributes found by the query
        """
        data = {"query": query}
        params = {"size": MAX_GET_SIZE}
        content = self.client.session.paginated(keys=["content"]).post(url=f"{self.tm_class.endpoint}search",
                                                                       json=data,
                                                                       params=params,
                                                                       )
        return [self.from_json(data) for data in content]

    def _query_rsql(self, key, ref, frameworks):
        """Boilerplate for executing RSQL search method. Mainly adds filters on the asset frameworks to search."""
        query = f"{key}=={ref}"
        if frameworks is not None:
            frameworks = self.client.asset.framework.list(frameworks)
            identifier_str = ",".join([source.identifier for source in frameworks])
            query = query + f";source.identifier=in=('{identifier_str}')"
        return self.by_rsql(query=query)

    def by_template(self, ref, frameworks=None):
        """Search assets by a given template

        Parameters
        ---------
        ref : str
            Full template or template substring
        frameworks : list, optional
            Asset frameworks in which to search. By default, all accessible frameworks are searched.

        Returns
        -------
        List[Union[Asset, Attribute]]
            List of assets and attributes found by the query
        """
        return self._query_rsql(key="template", ref=ref, frameworks=frameworks)

    def by_name(self, ref, frameworks=None):
        """Search assets by a given template

        Parameters
        ---------
        ref : str
            Full name or name substring
        frameworks : list, optional
            Asset frameworks in which to search. By default, all accessible frameworks are searched.

        Returns
        -------
        List[Union[Asset, Attribute]]
            List of assets and attributes found by the query
        """
        return self._query_rsql(key="name", ref=ref, frameworks=frameworks)

    def by_description(self, ref, frameworks=None):
        """Search assets by a given description

        Parameters
        ---------
        ref : str
            Full description of description substring
        frameworks : list, optional
            Asset frameworks in which to search. By default, all accessible frameworks are searched.

        Returns
        -------
        List[Union[Asset, Attribute]]
            List of assets and attributes found by the query
        """
        return self._query_rsql(key="description", ref=ref, frameworks=frameworks)

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_path_hex, self.from_path

    @property
    def _search_methods(self):
        return self.by_name, self.by_description