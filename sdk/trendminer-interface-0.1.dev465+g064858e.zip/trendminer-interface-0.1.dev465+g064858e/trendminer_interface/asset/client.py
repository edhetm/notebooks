import abc
from .factory import AssetFactory


class AssetClient(abc.ABC):
    @property
    def asset(self):
        return AssetFactory(client=self)

