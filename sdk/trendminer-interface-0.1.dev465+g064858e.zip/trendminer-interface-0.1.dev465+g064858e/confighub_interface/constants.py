datasource_default_raw = {
    "EXAQUANTUM": False,
    "HC": True,  # TM connector
    "IP21": False,
    "ODBC": True,
    "OLEDB": True,
    "PHD": False,
    "PIAFSDK": False,
    "PIAFSDK-AD": False,  # active directory authentication
    "PIOLEDB": False,
    "PIOLEDB-AD": False,
    "PROFICY": False,
    "SQLITE": True,
    "WONDERWARE": False,
}