import abc
import posixpath

from trendminer_interface.base import Savable, ByFactory, TrendMinerFactory, LazyLoadingClass, LazyAttribute
from .member import MemberFactoryACL, HasMembers


class BaseACL(Savable, HasMembers, LazyLoadingClass, abc.ABC):
    endpoint = None
    _members = ByFactory(MemberFactoryACL, "list")

    def __init__(self, client, name, members):
        super().__init__(client=client, identifier=name)
        self.name = name
        self._members = members

    @property
    def link(self):
        return posixpath.join(self.endpoint, "id", self.identifier)

    def _post_updates(self, response):
        self.identifier = self.name  # response is empty, write identifier directly from name

    def _put_updates(self, response):
        self._post_updates(response)

    def members_get(self):
        return self._members

    def member_add(self, member):
        member = MemberFactoryACL(client=self.client).get(member)
        self.client.session.post(url=f"{self.link}/members", json=member.json_member())
        self._members = LazyAttribute()

    def member_remove(self, member):
        member = MemberFactoryACL(client=self.client).get(member)
        params = {
            "member": member.path,
            "type": member.member_type,
        }
        response = self.client.session.delete(url=f"{self.link}/members/", params=params)
        self._members = LazyAttribute()

    def __json__(self):
        return {
            "entity": self.name,
            "permission": "READ",
            "members": [member.json_member() for member in self._members]
        }

    @property
    def blueprint(self):
        raise NotImplementedError()
        return

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self.name} >>"


class BaseACLFactory(TrendMinerFactory, abc.ABC):
    tm_class = BaseACL

    def __call__(self, name, members=None):
        return self.tm_class(
            client=self.client,
            name=name,
            members=members,
        )

    def all(self):
        response = self.client.session.get(self.tm_class.endpoint)
        return [self.from_json(data) for data in response.json()]

    def from_identifier(self, ref):
        response = self.client.session.get(f"{self.tm_class.endpoint}/id/{ref}")
        return self.from_json(response.json()[0])  # for some reason this returns a list with 1 result

    def from_name(self, ref):
        return self.from_identifier(ref)

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            name=data["entity"],
            members=data["members"]
        )

    @property
    def _get_methods(self):
        return self.from_identifier,
