from trendminer_interface.authentication import BaseClient


class ConfigHubBaseClient(BaseClient):

    def __init__(self, url, password, verify, keep_history, session_type):
        #self.session = session_type(base_url=url, verify=verify, keep_history=keep_history)

        super().__init__(
            url=url,
            client_id=None,
            client_secret=None,
            username=None,
            password=None,
            token=None,
            verify=verify,
            keep_history=keep_history,
            session_type=session_type,
        )

        self.session.config_login(password=password)