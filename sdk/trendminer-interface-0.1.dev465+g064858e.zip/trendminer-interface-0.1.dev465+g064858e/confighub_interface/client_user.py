from trendminer_interface.base import TrendMinerFactory
from .access import Member


class ClientUserClient:
    @property
    def client(self):
        return ClientUserFactory(client=self)


class ClientUser(Member):
    endpoint = "/confighub/clients"
    member_type = "CLIENT"

    def __init__(self, client, identifier):
        super().__init__(client=client, identifier=identifier, name=identifier)

    @property
    def path(self):
        return self.identifier

    def _post_updates(self, response):
        self.identifier = response.json()["id"]

    def _put_updates(self, response):
        self._post_updates(response)

    def __json__(self, password=None):
        return {
            "id": self.name,
        }

    def _full_instance(self):
        return ClientUserFactory(client=self.client).from_identifier(self.identifier)

    def blueprint(self):
        raise NotImplementedError

    def __repr__(self):
        return f"< {self.__class__.__name__} | {self.identifier} >"


class ClientUserFactory(TrendMinerFactory):
    tm_class = ClientUser

    def __call__(self, name):
        return self.tm_class(
            client=self.client,
            identifier=name,
        )

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
        )

    def from_json_member_acl(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["name"],
        )

    @property
    def _get_methods(self):
        return self.from_identifier,
