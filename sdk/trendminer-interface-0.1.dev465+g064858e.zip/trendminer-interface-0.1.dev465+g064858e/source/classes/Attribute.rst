Asset
=====

Class
-----
.. autoclass:: trendminer_interface.asset.Attribute()
    :members:
    :inherited-members:


Factory
-------
.. autoclass:: trendminer_interface.asset.factory.AssetFactory()
    :members:
    :inherited-members:
