Tag
===

Class
-----
.. autoclass:: trendminer_interface.tag.Tag()
    :members:
    :inherited-members:


Factory
-------
.. autoclass:: trendminer_interface.tag.TagFactory()
    :members:
    :inherited-members:
    :special-members: __call__

