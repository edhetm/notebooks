from pprint import pprint


def test_get(client):
    tag = client.tag.from_name("[CS]SINUSOID")
    assert tag.name == client.tag.from_name("[CS]sinusoid").name
    assert tag.identifier == client.tag.from_identifier(tag.identifier).identifier
    assert tag.identifier == client.tag.get(tag.name).identifier
    assert isinstance(client.tag.list(["[CS]SINUSOID", "[CS]SINUSOID_10m"]), list)


def test_search(client):
    all_tags = client.tag.all()
    print(len(all_tags))

    tags = client.tag.search("*BA:*.1")
    print(tags)

    tags = client.tag.by_name("TM-*")
    print(tags)

    tags = client.tag.by_description("*temperature*")
    print(tags)


def test_phases(client):
    tag = client.tag.from_name("TM-BP2-PRODUCT.1")
    assert "BETA" in tag.states
    tag = client.tag.from_identifier(tag.identifier)
    assert "ALPHA" in tag.states
    print(tag.datasource)


def test_data(client):
    tag = client.tag.from_name("[CS]BA:LEVEL.1")

    assert tag._empty_series().index.tzinfo.zone == "Europe/Brussels"

    data = tag.get_data("8h", form="interpolated", resolution='2m')
    assert len(data) > 100

    data = tag.get_data("8h", form="chart", resolution='1s')
    assert len(data) > 100

    period = ("2022-01-01", "2022-01-02")
    data = tag.get_data(period, form="index", resolution="1m")
    assert len(data) > 100
    assert data.index.tzinfo.zone == "Europe/Brussels"

    tag = client.tag.from_name("[CS]BA:PHASE.1")
    data = tag.get_data("1w", form="chart", resolution="1m")
    print(data)


def test_index(client):
    tag = client.tag.from_name("[CS]BA:PHASE.1")
    print(tag.index.status)
    tag.index.refresh()
    print(tag.index)
    tag.index.delete()
    print(tag.index)
    print(tag.index.tag)
    tag.index()


def test_calculations(client):
    tag = client.tag.from_name("[CS]BA:LEVEL.1")
    print(tag.calculate("1d", "mean"))
    print(tag.calculate(operation="max", intervals=["1d", "1w", "1M"], inplace=False))
    intervals = client.time.interval.list(["1d", "1w", "1M"])
    tag.calculate(operation="delta", intervals=intervals, inplace=True, key="difference")
    print(intervals[0].data)
    print(intervals[0]["difference"])
    tag = client.tag.from_name("[CS]BA:PHASE.1")
    print(tag.calculate("1h", "end")[0]["end"])


def test_index_search(client):
    incomplete = client.tag.index.all(status="INCOMPLETE")
    print([index.tag for index in incomplete])
    ba_indexes = client.tag.index.by_name("[CS]BA*")
    print([index.tag for index in ba_indexes])
