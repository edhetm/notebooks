from copy import deepcopy


def test_create(user, prefix):
    # basic formula
    formula = user.formula(
        name=prefix,
        formula="A+B",
        mapping={
            "A": "[CS]BA:LEVEL.1",
            "B": "[CS]BA:CONC.1",
        }
    )
    formula.post()
    formula.description = prefix
    formula.put()
    formula = user.formula.from_path(prefix)
    formula = user.formula.from_identifier(formula.identifier)
    formula.delete()

    # with shifts
    level = user.tag.from_name("[CS]BA:LEVEL.1")
    conc = user.tag.from_name("[CS]BA:CONC.1")
    conc.shift = 120
    phase = user.tag.from_name("[CS]BA:PHASE.1")
    phase_shifted = deepcopy(phase)
    phase_shifted.shift = "-1s"

    formula = user.formula(
        name=prefix,
        formula="if(A>10, A, max(sin(B)^2, tanh(B))) + phase + 0*phase_shifted",
        mapping={
            "A": level,
            "B": conc,
            "phase": phase,
            "phase_shifted": phase_shifted,
        }
    )
    formula.post()
    formula.description = prefix
    formula.put()
    formula = user.formula.from_path(prefix)
    formula = user.formula.from_identifier(formula.identifier)
    formula.delete()


def test_browse(user, prefix):
    folder = user.folder(name=prefix)
    folder.post()
    # basic formula
    formula = user.formula(
        name=prefix,
        formula="A",
        mapping={
            "A": "[CS]BA:LEVEL.1",
        },
        folder=folder
    )
    formula.post()
    formula = user.formula.from_path(f"{prefix}/{formula.name}")
    print(folder.browse())
    print(folder.browse(included=["formula"]))
    print(user.formula.search(prefix))
    formula.delete()
    folder.delete()


def test_digital_states(user, prefix):
    formula = user.formula(
        name=prefix,
        formula='if(or(v0="ALPHA", v0="BETA"), 100, 200)',
        mapping={
            "v0": "TM-BP2-PRODUCT.1",
        },
    )
    formula.post()
    formula.delete()