from pprint import pprint


def test_csv_upload(user, prefix):
    tags = user.tag.list(["[CS]BA:LEVEL.1", "[CS]BA:PHASE.1", "[CS]BA:CONC.1"])
    interval = user.time.interval("1d").shift("-1d")
    for tag in tags:
        tag.name = tag.name.replace("[CS]", f"[{prefix}]")
        tag.get_data(interval, inplace=True)
    user.io.tag.post(tags)
    user.io.tag.post(tags)
    user.io.tag.delete_all()


def test_work(user):
    data = user.io.work.export()
    data.update({"saved-items": []})  # empty the export
    user.io.work.upload(data) # upload empty data
    pprint(user.io.work.result())
