import json


def test_create(user, prefix):

    # folder
    folder = user.folder.from_path(prefix, create_new=True)

    # trend
    thv = user.trend.view(["[CS]BA:LEVEL.1"], layers=["8h"], live=True, name=prefix, folder=folder)
    thv.post()

    # context
    chv = user.context.view(
        name=prefix,
        filters=[
            user.context.filter.period("1h"),
            user.context.filter.components(["[CS]BA:CONC.1"]),
        ],
        folder=folder
    )
    chv.post()

    # monitor
    vbs = user.search.value("[CS]BA:LEVEL.1 > 0", name=prefix, folder=folder)
    vbs.post()
    monitor = user.monitor.from_search(vbs)
    monitor.enabled = True
    monitor.whatsnew.enabled = True
    monitor.put()

    # url
    url = "https://www.trendminer.com/wp-content/uploads/" \
          "2019/06/RGB-1-trendminer-logo-horizontal-fullcolor1200-300x90.png"

    # current values 1
    conditions1 = [
        user.dashboard.values.condition(">", 10, "red"),
        user.dashboard.values.condition("between", [0, 10], "orange"),
        (">=", 10, "#005EB8"),
        ]

    entries1 = [
        user.dashboard.values.entry(component="[CS]BA:LEVEL.1", color='black', conditions=conditions1)
    ]

    # current values 2
    entries2 = [
        user.dashboard.values.entry(
            component="PI2018 AF2/Cologne/BA Reactor1/Phase",
            conditions=[
                ("=", "Phase1", "green"),
                ("contains", "2", "yellow"),
                ("contains", "3", "orange"),
                ("does not contain", "4", "red"),
                ("!=", "Phase5", "red"),
            ]
        ),
        user.dashboard.values.entry(
            component="PI2018 AF2/Cologne/BA Reactor1/Concentration",
            color="black",
            conditions=[
                ("between", [0, 10], "green"),
                ("between", [10, 20], "orange"),
                (">", 20, "red"),
            ]
        ),
        user.dashboard.values.entry(
            component="PI2018 AF2/Cologne/BA Reactor1/Active",
            color="blue"
        ),
        user.dashboard.values.entry(
            component="PI2018 AF2/Cologne/BA Reactor1/Level",
            color="green",
            conditions=[
                ("not between", ["0, 30"], "red")
            ]
        ),
        user.dashboard.values.entry(
            component="PI2018 AF2/Cologne/BA Reactor1/Temperature",
            color="green",
            conditions=[
                ("not between", ["0, 30"], "red")
            ]
        ),
    ]

    # collect tiles
    tiles = [
        user.dashboard.trend(thv, x=0, y=0, rows=4, cols=4, title="Trend"),
        user.dashboard.count(chv, x=4, y=0, rows=4, cols=2, title="Count"),
        user.dashboard.gantt(chv, x=0, y=4, rows=4, cols=6, title="Gantt"),
        user.dashboard.table(chv, x=0, y=8, rows=4, cols=10),
        user.dashboard.monitor(monitor, x=6, y=0, rows=4, cols=2,
                               inactive_text="All good",
                               inactive_color="blue",
                               inactive_icon="snowflake",
                               ),
        user.dashboard.external(url, x=6, y=4, rows=4, cols=4),
        user.dashboard.values(entries1, x=8, y=0, rows=4, cols=2, graph=False, digits=0, timestamp=False),
        user.dashboard.values(entries2, x=10, y=0, rows=12, cols=2, graph_duration="2h", digits=1),
    ]

    # create dashboard
    db = user.dashboard(
        tiles=tiles,
        name=prefix,
        folder=folder,
        scrollable=True,
    )

    print(json.dumps(db.__json__(), indent=4))
    db.post()
    db = user.dashboard.from_identifier(db.identifier)
    print(db.tiles[0].content.get_data(resolution="5m"))
    print(db.tiles[4].content.name)

    db = user.dashboard.from_path(f"{prefix}/{prefix}")
    db.live = True
    db.scrollable = False
    db.put()

    print(folder.browse())

    folder.delete()
