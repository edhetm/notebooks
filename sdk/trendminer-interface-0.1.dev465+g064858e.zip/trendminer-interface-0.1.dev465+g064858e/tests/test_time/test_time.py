from datetime import datetime, timedelta
from trendminer_interface.times import Interval


def test_timedelta(client):
    assert client.time.timedelta("8h")
    assert client.time.timedelta("1y12h")
    assert client.time.timedelta("1d 14h 12s")
    assert client.time.timedelta("1d 25h 12s")
    assert client.time.timedelta("10M12d12h5s")
    assert client.time.timedelta("1y 3M 12d 4m12s 14ms")
    assert client.time.timedelta("15ms")
    assert client.time.timedelta("1s").total_seconds() == 1
    assert client.time.timedelta("135d").total_seconds() == 135*24*3600
    assert client.time.timedelta(100).total_seconds() == 100
    assert client.time.timedelta(timedelta(seconds=100)).total_seconds() == 100


def test_datetime(client):
    assert client.time.datetime("2021").month == 1
    assert client.time.datetime("2021-02-01 12:00:00.123").month == 2
    assert client.time.datetime("2021-02-01T12:00:00Z").tzinfo.zone == 'Europe/Brussels'
    assert client.time.now()
    assert client.index_horizon.tzinfo.zone == "Europe/Brussels"
    assert client.time.datetime(datetime(year=2022, month=1, day=1)).tzinfo.zone == 'Europe/Brussels'


def test_interval(client):
    assert client.time.interval("2021").duration > client.time.timedelta('1y')
    assert client.time.interval("2021-01-01 12:00:00", "2022").end.month == 1
    assert isinstance(client.time.interval("10M12d12h5s"), Interval)
    assert isinstance(client.time.all(), Interval)
    interval = client.time.interval("1h")
    print(interval)
    print(interval+"1h")
    print("1h"+interval)
    assert(client.time.interval("2022-01-01, 2023-01-01").duration > client.time.timedelta("360d"))


def test_period(client):
    assert client.time.period("8h")
    assert client.time.period("1y12h")
    assert client.time.period("1d 14h 12s")
    assert client.time.period("1d 25h 12s")
    assert client.time.period("10M12d12h5s")
    assert client.time.period("1y 3M 12d 4m12s 14ms")
    assert client.time.period("15ms")
    assert client.time.period("1s").duration.total_seconds() == 1
    assert client.time.period("135d").duration.total_seconds() == 135*24*3600
    assert client.time.period(100).duration.total_seconds() == 100
    assert client.time.period(timedelta(seconds=100)).duration.total_seconds() == 100
    assert client.time.period('1d').start.tzinfo.zone == 'Europe/Brussels'

    # Assert period keeps moving
    current_start = client.time.period('1h').end
    assert current_start != client.time.period('1h').end


def test_slice(client):
    # intervals
    assert client.time.slice("2021").duration > client.time.timedelta('1y')
    assert client.time.slice("2021-01-01 12:00:00", "2022").end.month == 1

    # periods
    assert client.time.slice("8h")
    assert client.time.slice("1y12h")
    assert client.time.slice("1d 14h 12s")
    assert client.time.slice("1d 25h 12s")
    assert client.time.slice("10M12d12h5s")
    assert client.time.slice("1y 3M 12d 4m12s 14ms")
    assert client.time.slice("15ms")
    assert client.time.slice("1s").duration.total_seconds() == 1
    assert client.time.slice("135d").duration.total_seconds() == 135*24*3600
    assert client.time.slice(100).duration.total_seconds() == 100
    assert client.time.slice(timedelta(seconds=100)).duration.total_seconds() == 100
    assert client.time.slice('1d').start.tzinfo.zone == 'Europe/Brussels'


def test_rounding(client):
    print(client.time.round("1h30m29s"))
    print(client.time.round("1h30m31s"))
    print(client.time.round(client.time.datetime("2022-01-01 12:12:40"), resolution="1h"))
    print(client.time.ceil(client.time.datetime("2022-01-01 12:12:40"), resolution="1h"))
    interval = client.time.interval("1h")
    print(client.time.round(interval,resolution="10s"))
    print(client.time.round(client.time.period("1h"),resolution="10s"))
    print(interval.narrow())


def test_invert(client):
    vbs = client.search.value(queries=[("[CS]BA:CONC.1", "<=", 42)])
    results = vbs.get_results("2d")
    inverted = client.time.interval.invert(results, span="2d")

    search_interval = client.time.interval("2023-01-01 10:00", "2023-01-01 22:00")
    included = [
        client.time.interval("2023-01-01 12:00", "2023-01-01 14:00"),
        client.time.interval("2023-01-01 18:00", "2023-01-01 20:00"),
    ]
    excluded = client.time.interval.invert(included, span=search_interval)
    print(excluded)


def test_ranges(client):
    weeks = client.time.interval.range(start="2022-01-01 08:00", freq="W", normalize=False, n_intervals=7)
    print(weeks)
    interval = client.time.interval("1W")
    print(interval.start)
    days = client.time.interval.range(start=interval.start, end=interval.end, freq="D", normalize=True)
    print(days)
