from json import dumps, loads
from pprint import pprint


def test_create(user, prefix):
    thv = user.trend.view(["[CS]BA:LEVEL.1"], layers=["8h"], live=True, name=prefix)
    thv.post()
    thv = user.trend.view.from_path(prefix)
    assert thv.live is True
    thv.live = False
    assert thv.live is False
    folder = user.folder(prefix)
    folder.post()
    thv.folder = folder
    thv.put()
    folder.delete()


def test_data(user, prefix):
    thv = user.trend.view(
        entries=[
            "[CS]BA:LEVEL.1",
            "[CS]BA:PHASE.1",
            "AF-example/Europe/Belgium/Hasselt/Fermentation/Fermenter/Stirrer_speed",
        ],
        layers=[
            ("2020", "2021"),
            ("2021", "2022"),
        ],
        live=True,
        name=prefix
    )
    thv.post()
    thv = user.trend.view.get(prefix)
    data = thv.get_data(resolution="1d", form="interpolated", fill=True)
    print(data)
    thv.delete()


def test_view(user):
    view = user.trend.view(entries=["[CS]BA:LEVEL.1", "[CS]BA:PHASE.1"], layers=["8h"])
    print(view.get_session_url())
    data = view.get_data(resolution="15m", form="chart", fill=True)[0]
    print(data.head())
    view = user.trend.view(layers=["8h"],
                           entries=[
                               "[CS]BA:PHASE.1",
                               "AF-example/Europe/Belgium/Hasselt/Fermentation/Fermenter/Stirrer_speed"
                           ])
    print(view.get_session_url())
