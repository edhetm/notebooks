from pprint import pprint


def test_create(user, prefix):
    search = user.search.value(["[CS]BA:LEVEL.1 > 0"], name=prefix)
    search.post()
    search = user.search.value.from_path(prefix)
    monitor = user.monitor.from_search(search)
    monitor._full_instance()
    monitor.whatsnew.enabled = True
    monitor.email.to = "wouter.daniels@softwareag.com"
    monitor.email.subject = prefix
    monitor.email.message = "QA SDK"
    monitor.email.enabled = True
    monitor.webhook.url = "https://www.trendminer.com"
    monitor.webhook.enabled = True
    monitor.enabled = True
    item = user.context.item("ANOMALY", ["[CS]BA:CONC.1"], description=prefix, keywords=[prefix])
    monitor.context.item = item
    monitor.context.enabled = True
    monitor.put()
    monitor = user.monitor.from_search(search)
    print(monitor.context.item)
    monitor.delete()
    search.delete()


def test_overview(user, prefix):
    search = user.search.value(["[CS]BA:LEVEL.1 > 0"], name=prefix)
    search.post()
    monitor = user.monitor.from_search(search)
    monitor.enabled = True
    monitor.put()
    monitor = user.monitor.from_identifier(monitor.identifier)
    monitor = user.monitor.from_name(monitor.name)
    print(monitor.name)
    pprint(user.monitor.overview(since="2022-01-01"))
    monitor = user.monitor.from_search(prefix)
    print(monitor)
    search.delete()


def test_all(user):
    print(user.monitor.all())
    print(user.monitor.all(active_only=False))

