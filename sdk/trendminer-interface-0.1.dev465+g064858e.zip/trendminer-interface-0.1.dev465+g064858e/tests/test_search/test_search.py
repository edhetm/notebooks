from pprint import pprint


def test_vbs(client, user, prefix):
    vbs = client.search.value("[CS]BA:LEVEL.1 > 10")
    results = vbs.get_results(interval="4h")
    vbs = client.search.value(("[CS]BA:PHASE.1", "=", ["phase1", "phase2"]), duration="15m")
    vbs.get_results(interval="1d")
    vbs = user.search.value(
        queries=[
            "[CS]BA:ACTIVE.1 constant",
            "[CS]BA:LEVEL.1 > 20",
        ],
        duration=3000,
        calculations={
            "test": ("[CS]BA:LEVEL.1", "mean"),
            "test2": ("SAP/Paint Process/Dispersion Vessel RES4001/Power", "max", "-"),
            "test3": ("[CS]BA:ACTIVE.1", "mean"),
        }
    )
    results = vbs.get_results(interval="7d", excluded_intervals=["1d"])
    print(results)
    vbs.name = prefix
    vbs.post()
    vbs = user.search.value.from_identifier(vbs.identifier)
    folder = user.folder.from_path(prefix, create_new=True)
    vbs.folder = folder
    vbs.put()
    vbs = user.search.value.from_path(f"{prefix}/{prefix}")
    vbs.description = prefix
    vbs.put()
    vbs.delete()
    folder.delete()


def test_vbs_2(client):
    vbs = client.search.value(queries=[("[CS]BA:CONC.1", "<=", 42)])
    results = vbs.get_results("2d")


def test_digital_calc(client, user):
    calculations = {
        "test": ("[CS]BA:ACTIVE.1", "start"),
    }

    uvbs = user.search.value(
        queries=["[CS]BA:LEVEL.1 > 10"],
        calculations=calculations,
    )
    pprint(uvbs.get_results("1d"))

    cvbs = user.search.value(
        queries=["[CS]BA:LEVEL.1 > 10"],
        calculations=calculations,
    )
    pprint(cvbs.get_results("1d"))