import pytest


def test_folder(user, prefix):
    root = user.folder.root()
    new_folder = user.folder(name=prefix, parent=root)
    new_folder.post()
    new_folder.name = prefix + "_edited"
    new_folder.put()
    new_folder = user.folder.get(new_folder.identifier)
    new_subfolder = user.folder(name=prefix, parent=new_folder.identifier)
    new_subfolder.post()
    new_folder.delete()


def test_browse(user, prefix):
    folder = user.folder.root().add_folder(prefix)
    chv = user.context.view(name=prefix, filters=user.context.filter.period('1h'), folder=folder)
    chv.post()
    chv.access.add('tclaes_test', "read")
    assert chv.identifier in [item.identifier for item in folder.browse()]
    assert chv.identifier in [item.identifier for item in folder.browse(included=chv.content_type)]
    folder.delete()
    with pytest.raises(ValueError):
        folder.browse(excluded="non-existing-content-type")
    print(user.folder.root().browse())


def test_path(user, prefix):
    path = f"{prefix}_l1/{prefix}_l2/{prefix}_l3"
    user.folder.from_path(path, create_new=True)
    folder = user.folder.get(path)
    chv = user.context.view(name=prefix, folder=folder, filters=user.context.filter.period('1h'))
    chv.post()
    assert chv.identifier == user.context.view.get(path + f"/{prefix}").identifier
    assert folder.folder
    main_folder = user.folder.get(prefix+'_l1')
    assert main_folder.subfolders()
    main_folder.delete()


def test_search(user, prefix):
    assert len(user.search.value.by_name(prefix)) == 0
    folder = user.folder(prefix)
    folder.post()
    db = user.dashboard(tiles=[], name=prefix, folder=folder)
    db.post()
    assert len(user.dashboard.by_name(prefix)) == 1
    db.delete()
    folder.delete()
