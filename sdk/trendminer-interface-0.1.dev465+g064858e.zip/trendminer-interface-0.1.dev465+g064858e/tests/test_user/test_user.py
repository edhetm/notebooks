def test_self(client, user):
    print(user.user.self())
    print(client.user.self())


def test_everyone(client):
    print(client.user.everyone())


def test_search(client):
    users = client.user.by_any(".")
    print(len(users))
